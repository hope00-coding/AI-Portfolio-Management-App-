
  # AI Portfolio Management App UI

  This is a code bundle for AI Portfolio Management App UI. The original project is available at https://www.figma.com/design/AKZtI4JAQ53xj2h3QQSv0D/AI-Portfolio-Management-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  