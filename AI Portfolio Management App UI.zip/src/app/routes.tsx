import { createBrowserRouter, Navigate } from "react-router";
import { Root } from "./components/vaultiq/Root";
import { SplashScreen } from "./components/vaultiq/SplashScreen";
import { OnboardingScreen } from "./components/vaultiq/OnboardingScreen";
import { LoginScreen } from "./components/vaultiq/LoginScreen";
import { AppLayout } from "./components/vaultiq/AppLayout";
import { DashboardScreen } from "./components/vaultiq/DashboardScreen";
import { PortfolioScreen } from "./components/vaultiq/PortfolioScreen";
import { AIInsightsScreen } from "./components/vaultiq/AIInsightsScreen";
import { DiscoverScreen } from "./components/vaultiq/DiscoverScreen";
import { AssetDetailScreen } from "./components/vaultiq/AssetDetailScreen";
import { SettingsScreen } from "./components/vaultiq/SettingsScreen";
import { BenchmarkScreen } from "./components/vaultiq/BenchmarkScreen";
import { NotesScreen } from "./components/vaultiq/NotesScreen";
import { ComponentLibraryScreen } from "./components/vaultiq/ComponentLibraryScreen";
import { SentimentScreen } from "./components/vaultiq/SentimentScreen";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      {
        index: true,
        element: <Navigate to="/splash" replace />,
      },
      {
        path: "splash",
        Component: SplashScreen,
      },
      {
        path: "onboarding",
        Component: OnboardingScreen,
      },
      {
        path: "login",
        Component: LoginScreen,
      },
      {
        path: "app",
        Component: AppLayout,
        children: [
          { index: true, Component: DashboardScreen },
          { path: "portfolio", Component: PortfolioScreen },
          { path: "insights", Component: AIInsightsScreen },
          { path: "discover", Component: DiscoverScreen },
          { path: "settings", Component: SettingsScreen },
          { path: "asset/:id", Component: AssetDetailScreen },
          { path: "sentiment", Component: SentimentScreen },
          { path: "benchmark", Component: BenchmarkScreen },
          { path: "notes", Component: NotesScreen },
          { path: "components", Component: ComponentLibraryScreen },
        ],
      },
    ],
  },
]);
