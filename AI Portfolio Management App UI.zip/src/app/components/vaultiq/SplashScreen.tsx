import { useEffect, useState } from "react";
import { useNavigate } from "react-router";

export function SplashScreen() {
  const navigate = useNavigate();
  const [showButtons, setShowButtons] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setShowButtons(true), 2000);
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 2;
      });
    }, 40);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, []);

  return (
    <div
      className="flex flex-col items-center justify-between h-full"
      style={{
        background:
          "radial-gradient(ellipse at 50% 35%, rgba(0,212,170,0.12) 0%, transparent 65%), #0A0E1A",
        padding: "48px 32px 40px",
      }}
    >
      {/* Top spacer */}
      <div />

      {/* Logo + Tagline */}
      <div className="flex flex-col items-center text-center">
        {/* Logo Mark */}
        <div
          className="relative mb-6"
          style={{ width: 90, height: 90 }}
        >
          {/* Outer ring */}
          <div
            className="absolute inset-0 rounded-full"
            style={{
              border: "1.5px solid rgba(0,212,170,0.3)",
              animation: "spin-slow 8s linear infinite",
            }}
          />
          {/* Dashed ring */}
          <div
            className="absolute inset-2 rounded-full"
            style={{
              border: "1px dashed rgba(0,212,170,0.15)",
            }}
          />
          {/* Core */}
          <div
            className="absolute inset-3 rounded-full flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, #00D4AA 0%, #00A882 100%)",
              boxShadow: "0 0 30px rgba(0,212,170,0.5), inset 0 1px 0 rgba(255,255,255,0.2)",
            }}
          >
            {/* Vault icon SVG */}
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <rect x="6" y="8" width="24" height="20" rx="3" stroke="white" strokeWidth="2" fill="none" />
              <circle cx="18" cy="18" r="5" stroke="white" strokeWidth="2" fill="none" />
              <circle cx="18" cy="18" r="2" fill="white" />
              <line x1="18" y1="13" x2="18" y2="10" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="23" y1="18" x2="26" y2="18" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="18" y1="23" x2="18" y2="26" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="13" y1="18" x2="10" y2="18" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              <rect x="28" y="15" width="2.5" height="6" rx="1.25" fill="white" />
            </svg>
          </div>
        </div>

        {/* App Name */}
        <div style={{ marginBottom: 12 }}>
          <span
            style={{
              fontSize: 40,
              fontWeight: 800,
              letterSpacing: -2,
              color: "white",
              lineHeight: 1,
            }}
          >
            VAULT
          </span>
          <span
            style={{
              fontSize: 40,
              fontWeight: 800,
              letterSpacing: -2,
              color: "#00D4AA",
              lineHeight: 1,
            }}
          >
            IQ
          </span>
        </div>

        {/* Tagline */}
        <p
          style={{
            fontSize: 15,
            color: "rgba(255,255,255,0.55)",
            letterSpacing: 0.2,
            lineHeight: 1.5,
            maxWidth: 220,
          }}
        >
          Your AI-powered investment companion
        </p>

        {/* Progress indicator */}
        {!showButtons && (
          <div className="mt-10 flex flex-col items-center gap-3">
            <div
              style={{
                width: 160,
                height: 2,
                background: "rgba(255,255,255,0.08)",
                borderRadius: 2,
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: `${progress}%`,
                  background: "linear-gradient(90deg, #00D4AA, #00A882)",
                  borderRadius: 2,
                  transition: "width 0.04s linear",
                }}
              />
            </div>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", letterSpacing: 1 }}>
              LOADING...
            </span>
          </div>
        )}
      </div>

      {/* Buttons */}
      <div
        className="w-full flex flex-col gap-3"
        style={{
          opacity: showButtons ? 1 : 0,
          transform: showButtons ? "translateY(0)" : "translateY(20px)",
          transition: "opacity 0.5s ease, transform 0.5s ease",
        }}
      >
        {/* Decorative dots */}
        <div className="flex justify-center gap-2 mb-2">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: i === 0 ? 20 : 6,
                height: 6,
                borderRadius: 3,
                background: i === 0 ? "#00D4AA" : "rgba(255,255,255,0.2)",
                transition: "all 0.3s",
              }}
            />
          ))}
        </div>

        <button
          onClick={() => navigate("/onboarding")}
          style={{
            width: "100%",
            height: 52,
            borderRadius: 14,
            background: "linear-gradient(135deg, #00D4AA 0%, #00A882 100%)",
            color: "#0A0E1A",
            fontWeight: 700,
            fontSize: 16,
            border: "none",
            cursor: "pointer",
            boxShadow: "0 8px 24px rgba(0,212,170,0.35)",
            letterSpacing: -0.3,
          }}
        >
          Get Started
        </button>

        <button
          onClick={() => navigate("/login")}
          style={{
            width: "100%",
            height: 52,
            borderRadius: 14,
            background: "rgba(255,255,255,0.05)",
            color: "rgba(255,255,255,0.85)",
            fontWeight: 600,
            fontSize: 16,
            border: "1px solid rgba(255,255,255,0.1)",
            cursor: "pointer",
            letterSpacing: -0.3,
          }}
        >
          Log In
        </button>

        <p
          style={{
            textAlign: "center",
            fontSize: 11,
            color: "rgba(255,255,255,0.25)",
            marginTop: 4,
          }}
        >
          By continuing, you agree to our Terms & Privacy Policy
        </p>
      </div>
    </div>
  );
}
