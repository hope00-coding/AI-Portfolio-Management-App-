import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import { Search, TrendingUp, TrendingDown, Filter, Star } from "lucide-react";
import { FUND_CATALOG } from "./data";

const CATEGORIES = ["Tümü", "Hisse Senedi", "Borçlanma", "Para Piyasası", "Altın", "Karma", "Fon Sepeti"];

const CATEGORY_ICONS: Record<string, string> = {
  "Tümü": "📊",
  "Hisse Senedi": "📈",
  "Borçlanma": "🏛️",
  "Para Piyasası": "💰",
  "Altın": "🥇",
  "Karma": "🔀",
  "Fon Sepeti": "📦",
};

const RISK_COLORS = ["", "#00D4AA", "#86EFAC", "#F5A623", "#FB923C", "#FF4D67"];

const FEATURED = ["GTE", "YAK", "ZMF"];

export function DiscoverScreen() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Tümü");
  const [sortBy, setSortBy] = useState<"return" | "risk" | "aum">("return");

  const filtered = useMemo(() => {
    let list = [...FUND_CATALOG];
    if (query) {
      const q = query.toLowerCase();
      list = list.filter((f) => f.name.toLowerCase().includes(q) || f.code.toLowerCase().includes(q));
    }
    if (category !== "Tümü") {
      list = list.filter((f) => f.category === category);
    }
    list.sort((a, b) => {
      if (sortBy === "return") return b.return1y - a.return1y;
      if (sortBy === "risk") return a.risk - b.risk;
      return 0;
    });
    return list;
  }, [query, category, sortBy]);

  const featured = FUND_CATALOG.filter((f) => FEATURED.includes(f.id));

  return (
    <div style={{ background: "#0A0E1A" }}>
      {/* Header */}
      <div style={{ padding: "16px 20px 12px" }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: -0.6, marginBottom: 4 }}>
          Keşfet
        </h2>
        <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
          500+ TEFAS fonu ve kıymetli metal
        </p>
      </div>

      {/* Search Bar */}
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14,
          padding: "0 14px", height: 46,
        }}>
          <Search size={16} color="rgba(255,255,255,0.3)" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Fon ara... (İPP, YAK, Altın...)"
            style={{
              flex: 1, background: "none", border: "none", outline: "none",
              color: "white", fontSize: 13, fontWeight: 400,
            }}
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", fontSize: 16, padding: 0 }}
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{ display: "flex", gap: 6, overflowX: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              style={{
                height: 34, paddingLeft: 12, paddingRight: 12, borderRadius: 10, border: "none", cursor: "pointer",
                fontSize: 12, fontWeight: 600, whiteSpace: "nowrap", flexShrink: 0,
                background: category === cat ? "#00D4AA" : "rgba(255,255,255,0.06)",
                color: category === cat ? "#0A0E1A" : "rgba(255,255,255,0.5)",
                display: "flex", alignItems: "center", gap: 5,
              }}
            >
              <span>{CATEGORY_ICONS[cat]}</span>
              <span>{cat}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Featured Funds */}
      {!query && category === "Tümü" && (
        <div style={{ padding: "0 16px 16px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: "white", letterSpacing: -0.3 }}>
              ⚡ Öne Çıkanlar
            </h3>
          </div>
          <div style={{ display: "flex", gap: 10, overflowX: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
            {featured.map((fund) => {
              const isPos = fund.change >= 0;
              return (
                <div
                  key={fund.id}
                  onClick={() => navigate(`/app/asset/${fund.id}`)}
                  style={{
                    minWidth: 140, flexShrink: 0,
                    background: "rgba(26,32,53,0.8)",
                    border: "1px solid rgba(255,255,255,0.07)",
                    borderRadius: 16, padding: "14px",
                    cursor: "pointer",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div style={{
                      background: isPos ? "rgba(0,212,170,0.12)" : "rgba(255,77,103,0.12)",
                      borderRadius: 8, padding: "3px 8px",
                    }}>
                      <span style={{
                        fontSize: 10, fontWeight: 800,
                        color: isPos ? "#00D4AA" : "#FF4D67",
                      }}>
                        {isPos ? "+" : ""}{fund.change.toFixed(2)}%
                      </span>
                    </div>
                    <Star size={14} color="rgba(255,255,255,0.2)" />
                  </div>
                  <p style={{ fontSize: 12, fontWeight: 800, color: "white", marginBottom: 2 }}>{fund.code}</p>
                  <p style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 10, lineHeight: 1.3 }}>
                    {fund.name.split(" ").slice(0, 3).join(" ")}
                  </p>
                  <div>
                    <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginBottom: 2 }}>1Y Getiri</p>
                    <p style={{ fontSize: 15, fontWeight: 800, color: "#00D4AA" }}>%{fund.return1y}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Sort bar */}
      <div style={{ padding: "0 16px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
          <span style={{ color: "white", fontWeight: 700 }}>{filtered.length}</span> fon
        </p>
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          <Filter size={12} color="rgba(255,255,255,0.3)" />
          {[
            { key: "return", label: "Getiri" },
            { key: "risk", label: "Risk" },
          ].map((s) => (
            <button
              key={s.key}
              onClick={() => setSortBy(s.key as any)}
              style={{
                height: 26, paddingLeft: 8, paddingRight: 8, borderRadius: 7, border: "none", cursor: "pointer",
                fontSize: 10, fontWeight: 600,
                background: sortBy === s.key ? "rgba(0,212,170,0.15)" : "transparent",
                color: sortBy === s.key ? "#00D4AA" : "rgba(255,255,255,0.35)",
              }}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Fund List */}
      <div style={{ padding: "0 16px 24px" }} className="flex flex-col gap-2">
        {filtered.map((fund, idx) => {
          const isPos = fund.change >= 0;
          return (
            <div
              key={fund.id}
              onClick={() => navigate(`/app/asset/${fund.id}`)}
              style={{
                display: "flex", alignItems: "center", gap: 12,
                background: "rgba(26,32,53,0.6)",
                border: "1px solid rgba(255,255,255,0.05)",
                borderRadius: 14, padding: "11px 14px", cursor: "pointer",
              }}
            >
              {/* Rank */}
              <span style={{
                fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.25)",
                width: 16, textAlign: "center", flexShrink: 0,
              }}>
                {idx + 1}
              </span>

              {/* Code badge */}
              <div style={{
                width: 40, height: 40, borderRadius: 11, flexShrink: 0,
                background: "rgba(0,212,170,0.08)", border: "1px solid rgba(0,212,170,0.15)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 9, fontWeight: 800, color: "#00D4AA", letterSpacing: -0.3,
              }}>
                {fund.code}
              </div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 12, fontWeight: 600, color: "white", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {fund.name}
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 3 }}>
                  <span style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.06)", borderRadius: 4, padding: "1px 5px" }}>
                    {fund.category}
                  </span>
                  <span style={{ fontSize: 9, color: "rgba(255,255,255,0.3)" }}>AUM: {fund.aum}</span>
                  {/* Risk dots */}
                  <div style={{ display: "flex", gap: 2 }}>
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} style={{
                        width: 5, height: 5, borderRadius: "50%",
                        background: i <= fund.risk ? RISK_COLORS[fund.risk] : "rgba(255,255,255,0.1)",
                      }} />
                    ))}
                  </div>
                </div>
              </div>

              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 3, justifyContent: "flex-end", marginBottom: 3 }}>
                  {isPos ? <TrendingUp size={10} color="#00D4AA" /> : <TrendingDown size={10} color="#FF4D67" />}
                  <span style={{ fontSize: 11, fontWeight: 700, color: isPos ? "#00D4AA" : "#FF4D67" }}>
                    {isPos ? "+" : ""}{fund.change.toFixed(2)}%
                  </span>
                </div>
                <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>
                  1Y: <span style={{ color: "#00D4AA", fontWeight: 700 }}>%{fund.return1y}</span>
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
