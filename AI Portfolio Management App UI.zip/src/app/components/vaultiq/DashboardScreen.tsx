import { useState, useMemo, useId } from "react";
import { useNavigate } from "react-router";
import {
  Bell, TrendingUp, TrendingDown, Zap, ChevronRight,
  ArrowUpRight, Plus, ShoppingCart, ArrowLeftRight, Minus,
  Flame, RefreshCw,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
} from "recharts";
import {
  PORTFOLIO_SUMMARY, CHART_DATA, HOLDINGS, AI_INSIGHTS,
  MARKET_SNAPSHOT, fmt, fmtCurrency,
} from "./data";

// ─── Currency config ───────────────────────────────────────────────────────────
const CURRENCIES = [
  { code: "TRY", symbol: "₺", rate: 1, label: "TRY" },
  { code: "USD", symbol: "$", rate: 1 / 32.84, label: "USD" },
  { code: "EUR", symbol: "€", rate: 1 / 35.62, label: "EUR" },
  { code: "GBP", symbol: "£", rate: 1 / 41.52, label: "GBP" },
] as const;

type CurrencyCode = (typeof CURRENCIES)[number]["code"];

// ─── Asset Allocation data ─────────────────────────────────────────────────────
const ALLOCATION_SEGMENTS = [
  { label: "TEFAS Fonları", pct: 87.0, color: "#00D4AA", shortLabel: "Fonlar" },
  { label: "Altın", pct: 7.9, color: "#F5A623", shortLabel: "Altın" },
  { label: "Gümüş", pct: 3.1, color: "#94A3B8", shortLabel: "Gümüş" },
  { label: "Platin", pct: 2.1, color: "#CBD5E1", shortLabel: "Platin" },
];

// ─── Sparkline tooltip ─────────────────────────────────────────────────────────
function SparkTooltip({ active, payload, symbol }: any) {
  if (active && payload?.length) {
    return (
      <div
        style={{
          background: "#1A2035",
          border: "1px solid rgba(0,212,170,0.3)",
          borderRadius: 8,
          padding: "4px 8px",
        }}
      >
        <span style={{ color: "#00D4AA", fontSize: 11, fontWeight: 700 }}>
          {symbol}{fmt(payload[0].value)}
        </span>
      </div>
    );
  }
  return null;
}

// ─── Quick Action Button ───────────────────────────────────────────────────────
function QuickAction({
  icon: Icon,
  label,
  color,
  bgColor,
  onClick,
}: {
  icon: any;
  label: string;
  color: string;
  bgColor: string;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 6,
        background: "none",
        border: "none",
        cursor: "pointer",
        padding: 0,
      }}
    >
      <div
        style={{
          width: 52,
          height: 52,
          borderRadius: 16,
          background: bgColor,
          border: `1.5px solid ${color}30`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: `0 4px 16px ${color}18`,
          transition: "transform 0.15s",
        }}
      >
        <Icon size={20} color={color} strokeWidth={2} />
      </div>
      <span
        style={{
          fontSize: 10,
          fontWeight: 600,
          color: "rgba(255,255,255,0.55)",
          letterSpacing: 0.2,
        }}
      >
        {label}
      </span>
    </button>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────────
export function DashboardScreen() {
  const [currency, setCurrency] = useState<CurrencyCode>("TRY");
  const navigate = useNavigate();
  const uid = useId();
  const gradId = `sparkGrad-${uid.replace(/:/g, "")}`;

  const { totalValue, todayChange, todayChangePct, totalGain } = PORTFOLIO_SUMMARY;

  // Get selected currency config
  const curr = CURRENCIES.find((c) => c.code === currency)!;

  // Convert values
  const displayTotal = totalValue * curr.rate;
  const displayChange = todayChange * curr.rate;
  const displayGain = totalGain * curr.rate;

  // Sparkline: use 7-day (1H) data
  const sparkData = CHART_DATA["1H"].map((d) => ({
    ...d,
    value: d.value * curr.rate,
  }));

  const isUp = todayChange >= 0;

  const topHoldings = HOLDINGS.slice(0, 4);
  const insight = AI_INSIGHTS[0];

  // today's date in Turkish
  const dateStr = useMemo(() => {
    return new Date().toLocaleDateString("tr-TR", {
      weekday: "long",
      day: "numeric",
      month: "long",
    });
  }, []);

  // Format display value
  function fmtDisplay(val: number) {
    if (currency === "TRY") return `₺${fmt(val, 0)}`;
    return `${curr.symbol}${fmt(val, 0)}`;
  }

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%" }}>
      {/* ── Data Freshness Indicator ───────────────────────── */}
      <div style={{
        margin: "10px 16px 0",
        display: "flex", alignItems: "center", gap: 6,
        background: "rgba(26,32,53,0.7)", border: "1px solid rgba(255,255,255,0.06)",
        borderRadius: 9, padding: "6px 10px",
      }}>
        <div style={{
          width: 6, height: 6, borderRadius: "50%",
          background: "#F59E0B",
          boxShadow: "0 0 5px rgba(245,158,11,0.7)",
          flexShrink: 0,
        }} />
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.5)", fontWeight: 600 }}>
          Önbellek: EOD Fiyatları
        </span>
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.28)", marginRight: "auto" }}>
          · Son Güncelleme {dateStr.split(" ").slice(-2).join(" ")} 18:30
        </span>
        <button
          style={{
            background: "none", border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 3, padding: 0,
          }}
        >
          <RefreshCw size={9} color="#00D4AA" />
          <span style={{ fontSize: 9, color: "#00D4AA", fontWeight: 700 }}>TEFAS Canlı</span>
        </button>
      </div>

      {/* ── Header ─────────────────────────────────────────── */}
      <div
        style={{
          padding: "10px 20px 10px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div>
          <p
            style={{
              fontSize: 11,
              color: "rgba(255,255,255,0.38)",
              fontWeight: 500,
              letterSpacing: 0.4,
              textTransform: "uppercase",
            }}
          >
            {dateStr}
          </p>
          <h2
            style={{
              fontSize: 19,
              fontWeight: 800,
              color: "white",
              letterSpacing: -0.5,
              marginTop: 2,
              lineHeight: 1.1,
            }}
          >
            Günaydın, Ahmet 👋
          </h2>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {/* Bell */}
          <button
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.08)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              position: "relative",
            }}
          >
            <Bell size={16} color="rgba(255,255,255,0.65)" />
            <div
              style={{
                position: "absolute",
                top: 8,
                right: 8,
                width: 7,
                height: 7,
                borderRadius: "50%",
                background: "#00D4AA",
                border: "1.5px solid #0A0E1A",
                boxShadow: "0 0 6px rgba(0,212,170,0.8)",
              }}
            />
          </button>

          {/* Avatar */}
          <div
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              background: "linear-gradient(135deg, #00D4AA 0%, #00A882 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 13,
              fontWeight: 800,
              color: "#0A0E1A",
              boxShadow: "0 4px 12px rgba(0,212,170,0.3)",
            }}
          >
            AY
          </div>
        </div>
      </div>

      {/* ── Portfolio Value Card ─────────────────────────── */}
      <div style={{ padding: "4px 16px 14px" }}>
        <div
          style={{
            borderRadius: 22,
            background:
              "linear-gradient(145deg, rgba(26,32,53,0.95) 0%, rgba(16,22,42,0.95) 100%)",
            border: "1px solid rgba(255,255,255,0.08)",
            overflow: "hidden",
            boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
          }}
        >
          {/* Currency Toggle */}
          <div
            style={{
              display: "flex",
              gap: 4,
              padding: "14px 16px 10px",
              borderBottom: "1px solid rgba(255,255,255,0.05)",
            }}
          >
            {CURRENCIES.map((c) => (
              <button
                key={c.code}
                onClick={() => setCurrency(c.code)}
                style={{
                  flex: 1,
                  height: 26,
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: 0.3,
                  transition: "all 0.2s",
                  background:
                    currency === c.code
                      ? "#00D4AA"
                      : "rgba(255,255,255,0.04)",
                  color:
                    currency === c.code
                      ? "#0A0E1A"
                      : "rgba(255,255,255,0.35)",
                  boxShadow:
                    currency === c.code
                      ? "0 2px 8px rgba(0,212,170,0.35)"
                      : "none",
                }}
              >
                {c.label}
              </button>
            ))}
          </div>

          {/* Value Area */}
          <div style={{ padding: "16px 18px 0" }}>
            {/* Label + badge */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 6,
              }}
            >
              <p
                style={{
                  fontSize: 10,
                  color: "rgba(255,255,255,0.38)",
                  fontWeight: 600,
                  letterSpacing: 1,
                  textTransform: "uppercase",
                }}
              >
                TOPLAM PORTFÖY DEĞERİ
              </p>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                  background: isUp
                    ? "rgba(0,212,170,0.12)"
                    : "rgba(255,77,103,0.12)",
                  border: `1px solid ${isUp ? "rgba(0,212,170,0.3)" : "rgba(255,77,103,0.3)"}`,
                  borderRadius: 8,
                  padding: "3px 8px",
                }}
              >
                {isUp ? (
                  <TrendingUp size={11} color="#00D4AA" />
                ) : (
                  <TrendingDown size={11} color="#FF4D67" />
                )}
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 700,
                    color: isUp ? "#00D4AA" : "#FF4D67",
                  }}
                >
                  {isUp ? "+" : ""}
                  {todayChangePct.toFixed(2)}%
                </span>
              </div>
            </div>

            {/* Big value */}
            <p
              style={{
                fontSize: 36,
                fontWeight: 900,
                color: "white",
                letterSpacing: -2,
                lineHeight: 1,
                marginBottom: 10,
              }}
            >
              {fmtDisplay(displayTotal)}
            </p>

            {/* Change row */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 16,
                marginBottom: 14,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <div
                  style={{
                    width: 18,
                    height: 18,
                    borderRadius: 5,
                    background: isUp
                      ? "rgba(0,212,170,0.15)"
                      : "rgba(255,77,103,0.15)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {isUp ? (
                    <TrendingUp size={10} color="#00D4AA" />
                  ) : (
                    <TrendingDown size={10} color="#FF4D67" />
                  )}
                </div>
                <span
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: isUp ? "#00D4AA" : "#FF4D67",
                  }}
                >
                  {isUp ? "+" : ""}
                  {curr.symbol}{fmt(Math.abs(displayChange), 0)}
                </span>
                <span
                  style={{
                    fontSize: 11,
                    color: "rgba(255,255,255,0.3)",
                  }}
                >
                  bugün
                </span>
              </div>

              <div
                style={{ width: 1, height: 14, background: "rgba(255,255,255,0.08)" }}
              />

              <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <span
                  style={{ fontSize: 12, fontWeight: 700, color: "#00D4AA" }}
                >
                  +{curr.symbol}{fmt(displayGain, 0)}
                </span>
                <span
                  style={{ fontSize: 11, color: "rgba(255,255,255,0.3)" }}
                >
                  toplam kâr
                </span>
              </div>
            </div>
          </div>

          {/* 7-Day Sparkline */}
          <div style={{ height: 90, marginLeft: -2, marginRight: -2 }}>
            {/* Hidden SVG to define gradient outside recharts to avoid key conflicts */}
            <svg width="0" height="0" style={{ position: "absolute" }}>
              <defs>
                <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00D4AA" stopOpacity={0.28} />
                  <stop offset="100%" stopColor="#00D4AA" stopOpacity={0} />
                </linearGradient>
              </defs>
            </svg>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={sparkData}
                margin={{ top: 5, right: 0, left: 0, bottom: 0 }}
              >
                <XAxis dataKey="time" hide />
                <YAxis domain={["auto", "auto"]} hide />
                <Tooltip
                  content={<SparkTooltip symbol={curr.symbol} />}
                  cursor={{ stroke: "rgba(0,212,170,0.2)", strokeWidth: 1 }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#00D4AA"
                  strokeWidth={2.5}
                  fill={`url(#${gradId})`}
                  dot={false}
                  activeDot={{ r: 4, fill: "#00D4AA", strokeWidth: 0 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Day labels under sparkline */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "4px 18px 14px",
            }}
          >
            {["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"].map((d) => (
              <span
                key={d}
                style={{
                  fontSize: 9,
                  color: "rgba(255,255,255,0.22)",
                  fontWeight: 500,
                }}
              >
                {d}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ── Asset Allocation Bar ─────────────────────────── */}
      <div style={{ padding: "0 16px 16px" }}>
        <div
          style={{
            background: "rgba(26,32,53,0.7)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 18,
            padding: "14px 16px",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 10,
            }}
          >
            <p
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: "rgba(255,255,255,0.5)",
                letterSpacing: 0.8,
                textTransform: "uppercase",
              }}
            >
              Varlık Dağılımı
            </p>
            <button
              onClick={() => navigate("/app/portfolio")}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                color: "#00D4AA",
                fontSize: 10,
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: 2,
              }}
            >
              Detay <ArrowUpRight size={10} />
            </button>
          </div>

          {/* Horizontal pill bar */}
          <div
            style={{
              height: 10,
              borderRadius: 6,
              overflow: "hidden",
              display: "flex",
              gap: 2,
              marginBottom: 10,
            }}
          >
            {ALLOCATION_SEGMENTS.map((seg) => (
              <div
                key={seg.label}
                style={{
                  width: `${seg.pct}%`,
                  background: seg.color,
                  borderRadius: 4,
                  minWidth: 4,
                  opacity: 0.9,
                }}
              />
            ))}
          </div>

          {/* Legend */}
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {ALLOCATION_SEGMENTS.map((seg) => (
              <div
                key={seg.label}
                style={{ display: "flex", alignItems: "center", gap: 5 }}
              >
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: 2,
                    background: seg.color,
                    flexShrink: 0,
                  }}
                />
                <span
                  style={{
                    fontSize: 10,
                    color: "rgba(255,255,255,0.5)",
                    fontWeight: 500,
                  }}
                >
                  {seg.shortLabel}
                </span>
                <span
                  style={{
                    fontSize: 10,
                    color: "rgba(255,255,255,0.8)",
                    fontWeight: 700,
                  }}
                >
                  {seg.pct}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Quick Actions ────────────────────────────────── */}
      <div style={{ padding: "0 16px 16px" }}>
        <div
          style={{
            background: "rgba(26,32,53,0.6)",
            border: "1px solid rgba(255,255,255,0.06)",
            borderRadius: 18,
            padding: "16px 12px 14px",
          }}
        >
          <p
            style={{
              fontSize: 11,
              fontWeight: 700,
              color: "rgba(255,255,255,0.5)",
              letterSpacing: 0.8,
              textTransform: "uppercase",
              marginBottom: 14,
              paddingLeft: 4,
            }}
          >
            Hızlı İşlemler
          </p>
          <div style={{ display: "flex", justifyContent: "space-around" }}>
            <QuickAction
              icon={Plus}
              label="Varlık Ekle"
              color="#00D4AA"
              bgColor="rgba(0,212,170,0.12)"
              onClick={() => navigate("/app/portfolio")}
            />
            <QuickAction
              icon={ShoppingCart}
              label="Al"
              color="#6366F1"
              bgColor="rgba(99,102,241,0.12)"
            />
            <QuickAction
              icon={Minus}
              label="Sat"
              color="#FF4D67"
              bgColor="rgba(255,77,103,0.12)"
            />
            <QuickAction
              icon={ArrowLeftRight}
              label="Dönüştür"
              color="#F59E0B"
              bgColor="rgba(245,158,11,0.12)"
            />
          </div>
        </div>
      </div>

      {/* ── AI Insight of the Day ───────────────────────── */}
      <div style={{ padding: "0 16px 16px" }}>
        <div
          onClick={() => navigate("/app/insights")}
          style={{
            background:
              "linear-gradient(135deg, rgba(0,212,170,0.07) 0%, rgba(99,102,241,0.05) 100%)",
            border: "1px solid rgba(0,212,170,0.2)",
            borderRadius: 18,
            padding: "14px 16px",
            cursor: "pointer",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {/* Glow accent */}
          <div
            style={{
              position: "absolute",
              top: -20,
              right: -20,
              width: 100,
              height: 100,
              borderRadius: "50%",
              background: "radial-gradient(circle, rgba(0,212,170,0.12) 0%, transparent 70%)",
              pointerEvents: "none",
            }}
          />

          {/* Header row */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              marginBottom: 10,
            }}
          >
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                background:
                  "linear-gradient(135deg, rgba(0,212,170,0.2), rgba(99,102,241,0.2))",
                border: "1px solid rgba(0,212,170,0.2)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <Zap size={16} color="#00D4AA" />
            </div>

            <div style={{ flex: 1 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  marginBottom: 1,
                }}
              >
                <span
                  style={{
                    fontSize: 10,
                    color: "#00D4AA",
                    fontWeight: 800,
                    letterSpacing: 0.8,
                    textTransform: "uppercase",
                  }}
                >
                  Günün AI Önerisi
                </span>
                <div
                  style={{
                    background: "rgba(0,212,170,0.15)",
                    border: "1px solid rgba(0,212,170,0.25)",
                    borderRadius: 4,
                    padding: "1px 5px",
                    fontSize: 9,
                    fontWeight: 800,
                    color: "#00D4AA",
                    letterSpacing: 0.5,
                  }}
                >
                  %{insight.confidence} GÜVEN
                </div>
              </div>
              <p
                style={{
                  fontSize: 12,
                  fontWeight: 700,
                  color: "white",
                  letterSpacing: -0.2,
                }}
              >
                {insight.title}
              </p>
            </div>

            <ChevronRight size={15} color="rgba(255,255,255,0.25)" />
          </div>

          {/* Body */}
          <p
            style={{
              fontSize: 12,
              color: "rgba(255,255,255,0.6)",
              lineHeight: 1.5,
              paddingLeft: 46,
            }}
          >
            {insight.body.substring(0, 90)}…
          </p>

          {/* Footer */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              marginTop: 10,
              paddingLeft: 46,
            }}
          >
            <Flame size={10} color="#F59E0B" />
            <span
              style={{
                fontSize: 10,
                color: "rgba(255,255,255,0.35)",
                fontWeight: 500,
              }}
            >
              {insight.time} • Tüm analizleri gör
            </span>
          </div>
        </div>
      </div>

      {/* ─ Top Holdings ─────────────────────────────────── */}
      <div style={{ padding: "0 16px 16px" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 10,
          }}
        >
          <h3
            style={{
              fontSize: 13,
              fontWeight: 700,
              color: "white",
              letterSpacing: -0.3,
            }}
          >
            Portföyüm
          </h3>
          <button
            onClick={() => navigate("/app/portfolio")}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "#00D4AA",
              fontSize: 11,
              fontWeight: 600,
              display: "flex",
              alignItems: "center",
              gap: 3,
            }}
          >
            Tümünü Gör <ArrowUpRight size={11} />
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {topHoldings.map((h) => {
            const isPositive = h.dayChange >= 0;
            const displayVal = h.value * curr.rate;
            return (
              <div
                key={h.id}
                onClick={() => navigate(`/app/asset/${h.id}`)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  background: "rgba(26,32,53,0.65)",
                  border: "1px solid rgba(255,255,255,0.055)",
                  borderRadius: 14,
                  padding: "11px 14px",
                  cursor: "pointer",
                  transition: "background 0.15s",
                }}
              >
                {/* Icon */}
                <div
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 12,
                    background: `${h.color}18`,
                    border: `1.5px solid ${h.color}35`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 10,
                    fontWeight: 900,
                    color: h.color,
                    flexShrink: 0,
                    letterSpacing: -0.5,
                  }}
                >
                  {h.code}
                </div>

                {/* Name & category */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p
                    style={{
                      fontSize: 13,
                      fontWeight: 600,
                      color: "white",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      letterSpacing: -0.2,
                    }}
                  >
                    {h.name.split(" ").slice(0, 3).join(" ")}
                  </p>
                  <p
                    style={{
                      fontSize: 10,
                      color: "rgba(255,255,255,0.35)",
                      marginTop: 2,
                    }}
                  >
                    {h.category} · %{h.allocation.toFixed(1)}
                  </p>
                </div>

                {/* Value & change */}
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <p
                    style={{
                      fontSize: 13,
                      fontWeight: 700,
                      color: "white",
                      letterSpacing: -0.3,
                    }}
                  >
                    {curr.symbol}{fmt(displayVal, 0)}
                  </p>
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: isPositive ? "#00D4AA" : "#FF4D67",
                      marginTop: 2,
                    }}
                  >
                    {isPositive ? "+" : ""}
                    {h.dayChange.toFixed(2)}%
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Market Snapshot ──────────────────────────────── */}
      <div style={{ padding: "0 16px 28px" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 10,
          }}
        >
          <h3
            style={{
              fontSize: 13,
              fontWeight: 700,
              color: "white",
              letterSpacing: -0.3,
            }}
          >
            Piyasa Özeti
          </h3>
          <button
            onClick={() => navigate("/app/discover")}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 4,
              color: "#00D4AA",
              fontSize: 11,
              fontWeight: 600,
            }}
          >
            <RefreshCw size={10} /> Canlı
          </button>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr 1fr",
            gap: 7,
          }}
        >
          {MARKET_SNAPSHOT.map((item) => {
            const isPos = item.change >= 0;
            return (
              <div
                key={item.label}
                style={{
                  background: "rgba(26,32,53,0.6)",
                  border: "1px solid rgba(255,255,255,0.05)",
                  borderRadius: 12,
                  padding: "10px 10px",
                  cursor: "pointer",
                }}
              >
                <div
                  style={{
                    fontSize: 14,
                    marginBottom: 4,
                    lineHeight: 1,
                  }}
                >
                  {item.icon}
                </div>
                <p
                  style={{
                    fontSize: 9,
                    color: "rgba(255,255,255,0.38)",
                    marginBottom: 3,
                    fontWeight: 600,
                    letterSpacing: 0.3,
                  }}
                >
                  {item.label}
                </p>
                <p
                  style={{
                    fontSize: 11,
                    fontWeight: 800,
                    color: "white",
                    letterSpacing: -0.3,
                  }}
                >
                  {item.value}
                </p>
                <p
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    color: isPos ? "#00D4AA" : "#FF4D67",
                    marginTop: 2,
                  }}
                >
                  {isPos ? "+" : ""}
                  {item.change.toFixed(2)}%
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}