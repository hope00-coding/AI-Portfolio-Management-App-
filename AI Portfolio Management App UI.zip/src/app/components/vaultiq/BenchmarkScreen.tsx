import { useState, useId } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, TrendingUp, TrendingDown, Award } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer, ReferenceLine,
} from "recharts";
import { BENCHMARK_DATA, BENCHMARK_STATS } from "./data";

const TIME_RANGES = ["1A", "3A", "6A", "1Y"] as const;
type TimeRange = typeof TIME_RANGES[number];

const BENCHMARKS = [
  { key: "portfolio", label: "Portföyüm",  color: "#00D4AA", enabled: true  },
  { key: "sp500",     label: "S&P 500",    color: "#6366F1", enabled: true  },
  { key: "nasdaq",    label: "NASDAQ 100", color: "#F59E0B", enabled: false },
  { key: "btc",       label: "Bitcoin",    color: "#F97316", enabled: false },
  { key: "gold",      label: "Altın",      color: "#EAB308", enabled: true  },
] as const;

type BenchmarkKey = typeof BENCHMARKS[number]["key"];

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "#1A2035", border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: 10, padding: "8px 12px", minWidth: 130,
    }}>
      <p style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 5 }}>{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} style={{ display: "flex", justifyContent: "space-between", gap: 12, marginBottom: 2 }}>
          <span style={{ fontSize: 11, color: p.color }}>{p.name}</span>
          <span style={{ fontSize: 11, fontWeight: 700, color: "white" }}>
            {p.value >= 100 ? "+" : ""}{(p.value - 100).toFixed(1)}%
          </span>
        </div>
      ))}
    </div>
  );
}

export function BenchmarkScreen() {
  const navigate = useNavigate();
  const uid = useId();
  const [range, setRange] = useState<TimeRange>("1Y");
  const [active, setActive] = useState<Set<BenchmarkKey>>(
    new Set(BENCHMARKS.filter((b) => b.enabled).map((b) => b.key))
  );

  const data = BENCHMARK_DATA[range];

  function toggle(key: BenchmarkKey) {
    setActive((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        if (next.size > 1) next.delete(key); // always keep at least 1
      } else {
        next.add(key);
      }
      return next;
    });
  }

  const stats = Object.entries(BENCHMARK_STATS).filter(([k]) =>
    active.has(k as BenchmarkKey)
  );

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%" }}>
      {/* Header */}
      <div style={{ padding: "12px 16px 14px", display: "flex", alignItems: "center", gap: 12 }}>
        <button
          onClick={() => navigate(-1)}
          style={{
            width: 36, height: 36, borderRadius: 11, display: "flex",
            alignItems: "center", justifyContent: "center",
            background: "rgba(255,255,255,0.06)", border: "none", cursor: "pointer",
          }}
        >
          <ArrowLeft size={16} color="white" />
        </button>
        <div style={{ flex: 1 }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, color: "white", letterSpacing: -0.5 }}>
            Benchmark Karşılaştırma
          </h2>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.38)", marginTop: 1 }}>
            Portföyünüz vs küresel endeksler
          </p>
        </div>
        <Award size={20} color="#00D4AA" />
      </div>

      {/* Time Range */}
      <div style={{ padding: "0 16px 14px", display: "flex", gap: 5 }}>
        {TIME_RANGES.map((r) => (
          <button
            key={r}
            onClick={() => setRange(r)}
            style={{
              flex: 1, height: 30, borderRadius: 8, border: "none", cursor: "pointer",
              fontSize: 11, fontWeight: 700,
              background: range === r ? "#00D4AA" : "rgba(255,255,255,0.06)",
              color: range === r ? "#0A0E1A" : "rgba(255,255,255,0.4)",
              transition: "all 0.2s",
            }}
          >
            {r}
          </button>
        ))}
      </div>

      {/* Benchmark Toggles */}
      <div style={{ padding: "0 16px 12px", display: "flex", gap: 6, flexWrap: "wrap" }}>
        {BENCHMARKS.map((b) => {
          const on = active.has(b.key);
          return (
            <button
              key={b.key}
              onClick={() => toggle(b.key)}
              style={{
                height: 28, paddingLeft: 10, paddingRight: 10,
                borderRadius: 8, border: `1.5px solid ${on ? b.color : "rgba(255,255,255,0.1)"}`,
                cursor: "pointer", display: "flex", alignItems: "center", gap: 5,
                background: on ? `${b.color}14` : "transparent",
                transition: "all 0.2s",
              }}
            >
              <div style={{
                width: 7, height: 7, borderRadius: "50%",
                background: on ? b.color : "rgba(255,255,255,0.2)",
              }} />
              <span style={{ fontSize: 10, fontWeight: 700, color: on ? b.color : "rgba(255,255,255,0.35)" }}>
                {b.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Chart */}
      <div style={{
        margin: "0 16px 14px",
        background: "rgba(26,32,53,0.7)", border: "1px solid rgba(255,255,255,0.06)",
        borderRadius: 20, padding: "16px 4px 8px",
      }}>
        <div style={{ height: 200 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
              <XAxis
                dataKey="time"
                tick={{ fontSize: 9, fill: "rgba(255,255,255,0.3)" }}
                axisLine={false} tickLine={false}
              />
              <YAxis
                domain={["auto", "auto"]}
                tick={{ fontSize: 9, fill: "rgba(255,255,255,0.3)" }}
                axisLine={false} tickLine={false}
                width={28}
                tickFormatter={(v) => `${(v - 100) >= 0 ? "+" : ""}${(v - 100).toFixed(0)}%`}
              />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={100} stroke="rgba(255,255,255,0.08)" strokeDasharray="3 3" />
              {BENCHMARKS.map((b) =>
                active.has(b.key) ? (
                  <Line
                    key={b.key}
                    type="monotone"
                    dataKey={b.key}
                    name={b.label}
                    stroke={b.color}
                    strokeWidth={b.key === "portfolio" ? 2.5 : 1.5}
                    dot={false}
                    activeDot={{ r: 3, fill: b.color, strokeWidth: 0 }}
                  />
                ) : null
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
        <p style={{ fontSize: 9, color: "rgba(255,255,255,0.2)", textAlign: "center", marginTop: 4 }}>
          Başlangıç = 100 bazında normalize edilmiş değerler
        </p>
      </div>

      {/* Performance Table */}
      <div style={{ padding: "0 16px 14px" }}>
        <h3 style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.45)", letterSpacing: 0.8, marginBottom: 10, textTransform: "uppercase" }}>
          Performans Özeti
        </h3>
        <div style={{
          background: "rgba(26,32,53,0.6)", border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: 16, overflow: "hidden",
        }}>
          {/* Table header */}
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 70px 70px 70px",
            padding: "10px 14px",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
          }}>
            {["", "Getiri", "Sharpe", "Max Kayıp"].map((h) => (
              <span key={h} style={{ fontSize: 9, fontWeight: 700, color: "rgba(255,255,255,0.3)", letterSpacing: 0.5, textAlign: h ? "right" : "left" }}>
                {h}
              </span>
            ))}
          </div>

          {stats.map(([key, s], i) => {
            const bm = BENCHMARKS.find((b) => b.key === key)!;
            const isPos = !s.ret.startsWith("-");
            return (
              <div
                key={key}
                style={{
                  display: "grid", gridTemplateColumns: "1fr 70px 70px 70px",
                  padding: "11px 14px", alignItems: "center",
                  borderTop: i > 0 ? "1px solid rgba(255,255,255,0.04)" : "none",
                  background: key === "portfolio" ? "rgba(0,212,170,0.04)" : "transparent",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 3, background: bm.color }} />
                  <span style={{ fontSize: 12, fontWeight: key === "portfolio" ? 700 : 500, color: key === "portfolio" ? "white" : "rgba(255,255,255,0.65)" }}>
                    {bm.label}
                  </span>
                  {key === "portfolio" && (
                    <span style={{ fontSize: 8, background: "rgba(0,212,170,0.15)", color: "#00D4AA", borderRadius: 4, padding: "1px 4px", fontWeight: 700 }}>
                      SİZ
                    </span>
                  )}
                </div>
                <span style={{ fontSize: 12, fontWeight: 700, color: isPos ? "#00D4AA" : "#FF4D67", textAlign: "right" }}>
                  {s.ret}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: "white", textAlign: "right" }}>
                  {s.sharpe}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: "#FF4D67", textAlign: "right" }}>
                  {s.maxDD}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Alpha card */}
      <div style={{ padding: "0 16px 28px" }}>
        <div style={{
          background: "linear-gradient(135deg, rgba(0,212,170,0.07), rgba(99,102,241,0.05))",
          border: "1px solid rgba(0,212,170,0.15)", borderRadius: 16, padding: "14px 16px",
          display: "flex", gap: 12, alignItems: "center",
        }}>
          <div style={{
            width: 42, height: 42, borderRadius: 12, flexShrink: 0,
            background: "rgba(0,212,170,0.12)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <TrendingUp size={20} color="#00D4AA" />
          </div>
          <div>
            <p style={{ fontSize: 12, fontWeight: 800, color: "white", marginBottom: 3 }}>
              S&P 500'ü <span style={{ color: "#00D4AA" }}>+9.44%</span> geride bıraktınız
            </p>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", lineHeight: 1.4 }}>
              AI destekli portföy yönetimi ile piyasanın üzerinde getiri elde ettiniz.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
