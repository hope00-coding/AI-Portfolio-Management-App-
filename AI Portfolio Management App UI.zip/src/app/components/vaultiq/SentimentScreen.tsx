import { useState } from "react";
import { TrendingUp, TrendingDown, Minus, ExternalLink, RefreshCw } from "lucide-react";
import { FINBERT_SENTIMENT, SENTIMENT_TWEETS, SENTIMENT_NEWS } from "./data";

// ─── FinBERT Sentiment Gauge ──────────────────────────────────────────────────
function SentimentGauge({
  bullish,
  neutral,
  bearish,
}: {
  bullish: number;
  neutral: number;
  bearish: number;
}) {
  const R = 72;
  const cx = 100;
  const cy = 88;
  const strokeW = 14;
  const totalAngle = 180;
  const toRad = (deg: number) => (deg * Math.PI) / 180;

  function arcPath(startDeg: number, endDeg: number) {
    const s = toRad(180 + startDeg);
    const e = toRad(180 + endDeg);
    const x1 = cx + R * Math.cos(s);
    const y1 = cy + R * Math.sin(s);
    const x2 = cx + R * Math.cos(e);
    const y2 = cy + R * Math.sin(e);
    const large = endDeg - startDeg > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${R} ${R} 0 ${large} 1 ${x2} ${y2}`;
  }

  const bearingEnd = (bearish / 100) * totalAngle;
  const neutralEnd = bearingEnd + (neutral / 100) * totalAngle;

  // Needle angle based on net sentiment (bullish tilts right, bearish tilts left)
  const netScore = bullish - bearish;
  const needleAngle = 180 + ((netScore + 100) / 200) * totalAngle;
  const needleRad = toRad(needleAngle);
  const needleLen = R - 10;
  const nx = cx + needleLen * Math.cos(needleRad);
  const ny = cy + needleLen * Math.sin(needleRad);

  return (
    <svg width={200} height={96} viewBox="0 0 200 96">
      {/* Track */}
      <path
        d={arcPath(0, 180)}
        stroke="rgba(255,255,255,0.07)"
        strokeWidth={strokeW}
        fill="none"
        strokeLinecap="round"
      />
      {/* Bearish arc */}
      <path
        d={arcPath(0, bearingEnd)}
        stroke="#FF4D67"
        strokeWidth={strokeW}
        fill="none"
        strokeLinecap="butt"
      />
      {/* Neutral arc */}
      <path
        d={arcPath(bearingEnd + 0.5, neutralEnd)}
        stroke="#94A3B8"
        strokeWidth={strokeW}
        fill="none"
        strokeLinecap="butt"
      />
      {/* Bullish arc */}
      <path
        d={arcPath(neutralEnd + 0.5, 180)}
        stroke="#00D4AA"
        strokeWidth={strokeW}
        fill="none"
        strokeLinecap="round"
      />
      {/* Needle */}
      <line
        x1={cx}
        y1={cy}
        x2={nx}
        y2={ny}
        stroke="white"
        strokeWidth={2}
        strokeLinecap="round"
      />
      <circle cx={cx} cy={cy} r={5} fill="white" />
      <circle cx={cx} cy={cy} r={2.5} fill="#0A0E1A" />
      {/* Labels */}
      <text x={14} y={cy + 18} fill="#FF4D67" fontSize={8} fontWeight="700">AYICI</text>
      <text x={172} y={cy + 18} fill="#00D4AA" fontSize={8} fontWeight="700" textAnchor="end">YÜKSELEN</text>
    </svg>
  );
}

// ─── Sentiment Pill ───────────────────────────────────────────────────────────
function SentimentPill({ sentiment }: { sentiment: string }) {
  const cfg = {
    positive: { color: "#00D4AA", bg: "rgba(0,212,170,0.12)", label: "POZİTİF" },
    negative: { color: "#FF4D67", bg: "rgba(255,77,103,0.12)", label: "NEGATİF" },
    neutral: { color: "#94A3B8", bg: "rgba(148,163,184,0.12)", label: "NÖTR" },
  }[sentiment] ?? { color: "#94A3B8", bg: "rgba(148,163,184,0.12)", label: "NÖTR" };

  return (
    <span
      style={{
        background: cfg.bg,
        color: cfg.color,
        fontSize: 8,
        fontWeight: 800,
        borderRadius: 4,
        padding: "2px 6px",
        letterSpacing: 0.4,
        flexShrink: 0,
      }}
    >
      {cfg.label}
    </span>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export function SentimentScreen() {
  const [refreshing, setRefreshing] = useState(false);

  function handleRefresh() {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 900);
  }

  const { bullish, neutral, bearish, label, updatedAt } = FINBERT_SENTIMENT;

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%" }}>
      {/* Header */}
      <div style={{ padding: "16px 20px 12px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: -0.6, marginBottom: 2 }}>
              Piyasa Duyarlılığı
            </h2>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,0.38)" }}>
              FinBERT AI · Son güncelleme: {updatedAt}
            </p>
          </div>
          <button
            onClick={handleRefresh}
            style={{
              width: 36, height: 36, borderRadius: 10,
              background: "rgba(0,212,170,0.08)", border: "1px solid rgba(0,212,170,0.18)",
              display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
            }}
          >
            <RefreshCw
              size={14}
              color="#00D4AA"
              style={{ transition: "transform 0.4s", transform: refreshing ? "rotate(360deg)" : "none" }}
            />
          </button>
        </div>
      </div>

      {/* FinBERT Gauge Card */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "linear-gradient(145deg, rgba(26,32,53,0.95) 0%, rgba(16,22,42,0.95) 100%)",
          border: "1px solid rgba(255,255,255,0.07)",
          borderRadius: 20,
          padding: "16px",
          overflow: "hidden",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
            <div style={{
              width: 24, height: 24, borderRadius: 6,
              background: "linear-gradient(135deg, rgba(0,212,170,0.25), rgba(99,102,241,0.2))",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <span style={{ fontSize: 12 }}>🧠</span>
            </div>
            <span style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.7)", letterSpacing: 0.3 }}>
              FinBERT Duygu Skoru
            </span>
            <span style={{
              background: "rgba(0,212,170,0.12)", color: "#00D4AA",
              fontSize: 9, fontWeight: 800, borderRadius: 4, padding: "2px 7px", letterSpacing: 0.5, marginLeft: "auto",
            }}>
              CANLI
            </span>
          </div>

          {/* Gauge */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
            <SentimentGauge bullish={bullish} neutral={neutral} bearish={bearish} />
            <div style={{ marginTop: -4, textAlign: "center" }}>
              <p style={{ fontSize: 18, fontWeight: 800, color: "#00D4AA", letterSpacing: -0.5 }}>{label}</p>
              <p style={{ fontSize: 10, color: "rgba(255,255,255,0.38)", marginTop: 2 }}>
                Genel Piyasa Eğilimi
              </p>
            </div>
          </div>

          {/* Score breakdown */}
          <div style={{
            display: "flex", gap: 0, borderTop: "1px solid rgba(255,255,255,0.05)",
            paddingTop: 14, marginTop: 10,
          }}>
            {[
              { label: "Yükseliş", val: bullish, color: "#00D4AA", icon: TrendingUp },
              { label: "Nötr", val: neutral, color: "#94A3B8", icon: Minus },
              { label: "Düşüş", val: bearish, color: "#FF4D67", icon: TrendingDown },
            ].map(({ label: lbl, val, color, icon: Icon }, i) => (
              <div key={lbl} style={{
                flex: 1, textAlign: "center",
                borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.06)" : "none",
              }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4, marginBottom: 4 }}>
                  <Icon size={10} color={color} />
                  <span style={{ fontSize: 18, fontWeight: 800, color }}>{val}%</span>
                </div>
                <p style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", letterSpacing: 0.3 }}>{lbl}</p>
                <div style={{ height: 3, background: "rgba(255,255,255,0.06)", borderRadius: 2, margin: "6px auto 0", width: "60%" }}>
                  <div style={{ height: "100%", width: `${val}%`, background: color, borderRadius: 2 }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Twitter/X Feed */}
      <div style={{ padding: "0 0 16px" }}>
        <div style={{ padding: "0 20px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.253 5.622 5.911-5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: "white" }}>Finansal Tweet'ler</h3>
          </div>
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>AI Sentiment Analizi</span>
        </div>

        {/* Horizontal scrolling tweet cards */}
        <div
          className="no-scrollbar"
          style={{
            display: "flex", gap: 10, overflowX: "auto", overflowY: "hidden",
            paddingLeft: 16, paddingRight: 16, paddingBottom: 4,
          }}
        >
          {SENTIMENT_TWEETS.map((tweet) => (
            <div
              key={tweet.id}
              style={{
                flexShrink: 0,
                width: 220,
                background: "rgba(26,32,53,0.8)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 16,
                padding: "12px 13px",
              }}
            >
              {/* Tweet header */}
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{
                  width: 32, height: 32, borderRadius: "50%",
                  background: `${tweet.avatarColor}22`,
                  border: `1.5px solid ${tweet.avatarColor}50`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 10, fontWeight: 800, color: tweet.avatarColor, flexShrink: 0,
                }}>
                  {tweet.avatar}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 11, fontWeight: 700, color: "white", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {tweet.name}
                  </p>
                  <p style={{ fontSize: 9, color: "rgba(255,255,255,0.35)" }}>{tweet.handle}</p>
                </div>
                <SentimentPill sentiment={tweet.sentiment} />
              </div>

              {/* Tweet text */}
              <p style={{
                fontSize: 11, color: "rgba(255,255,255,0.7)", lineHeight: 1.5,
                display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical",
                overflow: "hidden",
              } as any}>
                {tweet.text}
              </p>

              {/* Footer */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8 }}>
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.28)" }}>{tweet.time}</span>
                <div style={{ display: "flex", alignItems: "center", gap: 3 }}>
                  <span style={{ fontSize: 9, color: "rgba(255,255,255,0.3)" }}>Güven:</span>
                  <span style={{
                    fontSize: 9, fontWeight: 800,
                    color: tweet.score > 0.7 ? "#00D4AA" : tweet.score < 0.4 ? "#FF4D67" : "#94A3B8",
                  }}>
                    %{Math.round(tweet.score * 100)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RSS News Feed */}
      <div style={{ padding: "0 16px 32px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "white" }}>Finansal Haberler</h3>
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>AI Sınıflandırma</span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {SENTIMENT_NEWS.map((news) => (
            <div
              key={news.id}
              style={{
                background: "rgba(26,32,53,0.65)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 14,
                padding: "12px 14px",
                cursor: "pointer",
              }}
            >
              {/* Top row: sentiment pill + source + time */}
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 7 }}>
                <SentimentPill sentiment={news.sentiment} />
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.4)", fontWeight: 600 }}>
                  {news.source}
                </span>
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", marginLeft: "auto" }}>
                  {news.time}
                </span>
              </div>

              {/* Headline */}
              <p style={{ fontSize: 12, fontWeight: 700, color: "white", lineHeight: 1.4, marginBottom: 5 }}>
                {news.headline}
              </p>

              {/* Summary */}
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.45)", lineHeight: 1.5, marginBottom: 8 }}>
                {news.summary}
              </p>

              {/* Footer */}
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{
                  background: "rgba(255,255,255,0.05)",
                  borderRadius: 4, padding: "2px 7px",
                  fontSize: 9, fontWeight: 600, color: "rgba(255,255,255,0.4)",
                }}>
                  {news.category}
                </span>
                <ExternalLink size={10} color="rgba(255,255,255,0.2)" style={{ marginLeft: "auto" }} />
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div style={{
          marginTop: 16,
          padding: "10px 13px",
          background: "rgba(99,102,241,0.07)",
          border: "1px solid rgba(99,102,241,0.15)",
          borderRadius: 10,
        }}>
          <p style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", lineHeight: 1.5, textAlign: "center" }}>
            📊 Haberler ve tweet duyarlılıkları FinBERT NLP modeli tarafından sınıflandırılmıştır.
            Gerçek zamanlı RSS akışı simüle edilmektedir.
          </p>
        </div>
      </div>
    </div>
  );
}
