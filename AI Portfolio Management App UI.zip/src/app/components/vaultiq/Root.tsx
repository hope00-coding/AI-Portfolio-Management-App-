import { Outlet } from "react-router";

function SignalBars() {
  return (
    <svg width="17" height="12" viewBox="0 0 17 12" fill="none">
      <rect x="0" y="8" width="3" height="4" rx="1" fill="white" />
      <rect x="4.5" y="5" width="3" height="7" rx="1" fill="white" />
      <rect x="9" y="2" width="3" height="10" rx="1" fill="white" />
      <rect x="13.5" y="0" width="3" height="12" rx="1" fill="white" fillOpacity="0.35" />
    </svg>
  );
}

function WifiIcon() {
  return (
    <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
      <path d="M8 9.5C8.83 9.5 9.5 10.17 9.5 11S8.83 12.5 8 12.5 6.5 11.83 6.5 11 7.17 9.5 8 9.5z" fill="white" />
      <path d="M3.5 6.5C5 4.9 6.4 4 8 4s3 .9 4.5 2.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      <path d="M1 3.5C3.2 1.2 5.5 0 8 0s4.8 1.2 7 3.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" strokeOpacity="0.5" />
    </svg>
  );
}

function BatteryIcon() {
  return (
    <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
      <rect x="0.5" y="0.5" width="21" height="11" rx="3.5" stroke="white" strokeOpacity="0.35" />
      <rect x="2" y="2" width="16" height="8" rx="2" fill="white" />
      <path d="M23 4v4c.83-.37 1.5-1.15 1.5-2S23.83 4.37 23 4z" fill="white" fillOpacity="0.4" />
    </svg>
  );
}

export function Root() {
  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{
        background:
          "radial-gradient(ellipse at 40% 20%, rgba(0,212,170,0.07) 0%, transparent 55%), radial-gradient(ellipse at 70% 80%, rgba(99,102,241,0.05) 0%, transparent 50%), linear-gradient(160deg, #050810 0%, #08101E 50%, #050810 100%)",
        padding: "16px",
      }}
    >
      {/* Ambient glow elements */}
      <div
        style={{
          position: "fixed",
          top: "15%",
          left: "50%",
          transform: "translateX(-50%)",
          width: 500,
          height: 500,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0,212,170,0.04) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Phone Frame */}
      <div
        style={{
          width: 390,
          height: 844,
          background: "#0A0E1A",
          borderRadius: 52,
          border: "11px solid #1C2238",
          boxShadow:
            "0 0 0 1px rgba(255,255,255,0.07), inset 0 0 0 1px rgba(255,255,255,0.04), 0 80px 160px rgba(0,0,0,0.85), 0 0 80px rgba(0,212,170,0.06)",
          position: "relative",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
        }}
      >
        {/* Side buttons */}
        <div
          style={{
            position: "absolute",
            left: -13,
            top: 130,
            width: 4,
            height: 32,
            background: "#1C2238",
            borderRadius: "2px 0 0 2px",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: -13,
            top: 174,
            width: 4,
            height: 64,
            background: "#1C2238",
            borderRadius: "2px 0 0 2px",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: -13,
            top: 248,
            width: 4,
            height: 64,
            background: "#1C2238",
            borderRadius: "2px 0 0 2px",
          }}
        />
        <div
          style={{
            position: "absolute",
            right: -13,
            top: 180,
            width: 4,
            height: 80,
            background: "#1C2238",
            borderRadius: "0 2px 2px 0",
          }}
        />

        {/* Dynamic Island */}
        <div
          style={{
            position: "absolute",
            top: 10,
            left: "50%",
            transform: "translateX(-50%)",
            width: 120,
            height: 34,
            background: "#000",
            borderRadius: 20,
            zIndex: 60,
          }}
        />

        {/* Status Bar */}
        <div
          style={{
            height: 52,
            paddingTop: 14,
            paddingLeft: 26,
            paddingRight: 20,
            display: "flex",
            alignItems: "flex-end",
            paddingBottom: 4,
            flexShrink: 0,
            color: "white",
            zIndex: 40,
          }}
        >
          <span style={{ flex: 1, fontSize: 15, fontWeight: 600, letterSpacing: -0.3 }}>
            9:41
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <SignalBars />
            <WifiIcon />
            <BatteryIcon />
          </div>
        </div>

        {/* Screen Content Area */}
        <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          <Outlet />
        </div>

        {/* Home Indicator */}
        <div
          style={{
            height: 28,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          <div
            style={{
              width: 130,
              height: 5,
              background: "rgba(255,255,255,0.22)",
              borderRadius: 3,
            }}
          />
        </div>
      </div>
    </div>
  );
}
