import { useState } from "react";
import { useNavigate } from "react-router";

const SLIDES = [
  {
    icon: (
      <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
        <rect x="4" y="12" width="56" height="42" rx="6" stroke="#00D4AA" strokeWidth="2" fill="rgba(0,212,170,0.08)" />
        <path d="M12 38 L22 28 L30 34 L40 22 L52 26" stroke="#00D4AA" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <circle cx="52" cy="26" r="3" fill="#00D4AA" />
        <path d="M12 44 L52 44" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
        <rect x="14" y="46" width="6" height="8" rx="1" fill="#00D4AA" fillOpacity="0.6" />
        <rect x="23" y="42" width="6" height="12" rx="1" fill="#00D4AA" fillOpacity="0.8" />
        <rect x="32" y="44" width="6" height="10" rx="1" fill="#00D4AA" fillOpacity="0.5" />
        <rect x="41" y="40" width="6" height="14" rx="1" fill="#00D4AA" />
      </svg>
    ),
    title: "Smart Portfolio\nTracking",
    subtitle:
      "Track all your TEFAS mutual funds and precious metals in one place. Real-time NAV updates and instant performance metrics.",
    tag: "📊 TEFAS + Metals",
  },
  {
    icon: (
      <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
        <circle cx="32" cy="32" r="28" stroke="#00D4AA" strokeWidth="1.5" fill="rgba(0,212,170,0.05)" strokeDasharray="4 2" />
        <circle cx="32" cy="32" r="18" fill="rgba(0,212,170,0.1)" stroke="#00D4AA" strokeWidth="2" />
        <path d="M24 32 L29 37 L40 26" stroke="#00D4AA" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <circle cx="14" cy="20" r="5" fill="#1A2035" stroke="#F5A623" strokeWidth="1.5" />
        <text x="14" y="23" textAnchor="middle" fontSize="6" fill="#F5A623" fontWeight="bold">AI</text>
        <circle cx="50" cy="20" r="5" fill="#1A2035" stroke="#6366F1" strokeWidth="1.5" />
        <text x="50" y="23" textAnchor="middle" fontSize="6" fill="#6366F1" fontWeight="bold">ML</text>
        <circle cx="14" cy="44" r="5" fill="#1A2035" stroke="#EC4899" strokeWidth="1.5" />
        <text x="14" y="47" textAnchor="middle" fontSize="5" fill="#EC4899" fontWeight="bold">NLP</text>
        <circle cx="50" cy="44" r="5" fill="#1A2035" stroke="#00D4AA" strokeWidth="1.5" />
        <text x="50" y="47" textAnchor="middle" fontSize="5" fill="#00D4AA" fontWeight="bold">RL</text>
        <line x1="19" y1="22" x2="24" y2="26" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
        <line x1="45" y1="22" x2="40" y2="26" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
        <line x1="19" y1="42" x2="24" y2="38" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
        <line x1="45" y1="42" x2="40" y2="38" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      </svg>
    ),
    title: "AI-Powered\nInsights",
    subtitle:
      "Our AI analyzes 200+ market signals to give you buy/sell recommendations, risk alerts, and rebalancing suggestions in real-time.",
    tag: "🤖 Machine Learning",
  },
  {
    icon: (
      <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
        {/* Gold bar */}
        <rect x="8" y="28" width="22" height="14" rx="3" fill="#F5A623" opacity="0.9" />
        <rect x="10" y="30" width="18" height="4" rx="1" fill="rgba(255,255,255,0.3)" />
        <text x="19" y="42" textAnchor="middle" fontSize="5" fill="rgba(0,0,0,0.5)" fontWeight="bold">ALTIN</text>
        {/* Silver bar */}
        <rect x="8" y="44" width="16" height="10" rx="2" fill="#94A3B8" opacity="0.9" />
        <rect x="10" y="46" width="12" height="3" rx="1" fill="rgba(255,255,255,0.3)" />
        {/* Platinum */}
        <rect x="26" y="44" width="14" height="10" rx="2" fill="#CBD5E1" opacity="0.8" />
        {/* TEFAS card */}
        <rect x="34" y="14" width="24" height="32" rx="4" fill="#1A2035" stroke="#00D4AA" strokeWidth="1.5" />
        <rect x="37" y="18" width="18" height="3" rx="1.5" fill="#00D4AA" fillOpacity="0.6" />
        <rect x="37" y="24" width="12" height="2" rx="1" fill="rgba(255,255,255,0.2)" />
        <rect x="37" y="28" width="14" height="2" rx="1" fill="rgba(255,255,255,0.15)" />
        <path d="M37 36 L41 32 L45 35 L52 30" stroke="#00D4AA" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <text x="46" y="44" textAnchor="middle" fontSize="6" fill="#00D4AA" fontWeight="bold">TEFAS</text>
      </svg>
    ),
    title: "TEFAS Funds &\nPrecious Metals",
    subtitle:
      "Access the full TEFAS catalog with 500+ mutual funds. Track gold, silver, and platinum alongside your fund portfolio seamlessly.",
    tag: "🥇 TEFAS + Kıymetli Maden",
  },
];

export function OnboardingScreen() {
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  const slide = SLIDES[current];

  const handleNext = () => {
    if (current < SLIDES.length - 1) {
      setCurrent((c) => c + 1);
    } else {
      navigate("/login");
    }
  };

  return (
    <div
      className="flex flex-col h-full"
      style={{ background: "#0A0E1A", padding: "0 28px 32px" }}
    >
      {/* Skip */}
      <div className="flex justify-end pt-4 pb-2">
        <button
          onClick={() => navigate("/login")}
          style={{
            background: "none",
            border: "none",
            color: "rgba(255,255,255,0.4)",
            fontSize: 14,
            fontWeight: 500,
            cursor: "pointer",
            padding: "4px 0",
          }}
        >
          Skip
        </button>
      </div>

      {/* Illustration */}
      <div
        className="flex-1 flex flex-col items-center justify-center"
        key={current}
        style={{ animation: "fadeInUp 0.4s ease-out" }}
      >
        {/* Circle bg */}
        <div
          style={{
            width: 160,
            height: 160,
            borderRadius: "50%",
            background:
              "radial-gradient(circle, rgba(0,212,170,0.1) 0%, transparent 70%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 40,
            position: "relative",
          }}
        >
          <div
            style={{
              width: 120,
              height: 120,
              borderRadius: "50%",
              background: "rgba(26,32,53,0.8)",
              border: "1px solid rgba(0,212,170,0.15)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 0 40px rgba(0,212,170,0.12)",
            }}
          >
            {slide.icon}
          </div>
        </div>

        {/* Tag */}
        <div
          style={{
            background: "rgba(0,212,170,0.1)",
            border: "1px solid rgba(0,212,170,0.2)",
            borderRadius: 20,
            padding: "4px 14px",
            color: "#00D4AA",
            fontSize: 12,
            fontWeight: 600,
            marginBottom: 20,
            letterSpacing: 0.3,
          }}
        >
          {slide.tag}
        </div>

        {/* Title */}
        <h2
          style={{
            fontSize: 28,
            fontWeight: 800,
            color: "white",
            textAlign: "center",
            letterSpacing: -0.8,
            marginBottom: 16,
            lineHeight: 1.2,
            whiteSpace: "pre-line",
          }}
        >
          {slide.title}
        </h2>

        {/* Subtitle */}
        <p
          style={{
            fontSize: 14,
            color: "rgba(255,255,255,0.5)",
            textAlign: "center",
            lineHeight: 1.65,
            maxWidth: 280,
          }}
        >
          {slide.subtitle}
        </p>
      </div>

      {/* Bottom: dots + button */}
      <div className="flex flex-col gap-4">
        {/* Progress dots */}
        <div className="flex justify-center gap-2">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              style={{
                width: i === current ? 24 : 8,
                height: 8,
                borderRadius: 4,
                background: i === current ? "#00D4AA" : "rgba(255,255,255,0.15)",
                border: "none",
                cursor: "pointer",
                transition: "all 0.3s ease",
              }}
            />
          ))}
        </div>

        <button
          onClick={handleNext}
          style={{
            width: "100%",
            height: 52,
            borderRadius: 14,
            background: "linear-gradient(135deg, #00D4AA 0%, #00A882 100%)",
            color: "#0A0E1A",
            fontWeight: 700,
            fontSize: 16,
            border: "none",
            cursor: "pointer",
            boxShadow: "0 8px 24px rgba(0,212,170,0.3)",
            letterSpacing: -0.3,
          }}
        >
          {current < SLIDES.length - 1 ? "Continue" : "Get Started"}
        </button>
      </div>
    </div>
  );
}
