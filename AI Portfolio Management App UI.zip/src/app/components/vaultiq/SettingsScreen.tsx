import { useState } from "react";
import { useNavigate } from "react-router";
import {
  User, Shield, Bell, Palette, HelpCircle, LogOut,
  ChevronRight, Fingerprint, Eye, Moon, Globe, Zap,
  FileText, AlertCircle, CheckCircle, StickyNote, LayoutGrid, Award,
} from "lucide-react";
import { USER, PORTFOLIO_SUMMARY, fmt } from "./data";

function ToggleSwitch({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      style={{
        width: 40, height: 22, borderRadius: 11,
        background: on ? "#00D4AA" : "rgba(255,255,255,0.1)",
        border: "none", cursor: "pointer", position: "relative",
        transition: "background 0.2s", flexShrink: 0,
      }}
    >
      <div style={{
        position: "absolute", top: 2,
        left: on ? 20 : 2,
        width: 18, height: 18, borderRadius: "50%",
        background: "white",
        transition: "left 0.2s",
        boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
      }} />
    </button>
  );
}

function SettingItem({
  icon: Icon, iconColor = "#00D4AA", iconBg, label, sub, value, hasArrow = true, onPress, danger = false, rightEl,
}: {
  icon: any; iconColor?: string; iconBg?: string; label: string; sub?: string;
  value?: string; hasArrow?: boolean; onPress?: () => void; danger?: boolean; rightEl?: React.ReactNode;
}) {
  return (
    <button
      onClick={onPress}
      style={{
        width: "100%", display: "flex", alignItems: "center", gap: 12,
        padding: "12px 0", background: "none", border: "none", cursor: "pointer", textAlign: "left",
      }}
    >
      <div style={{
        width: 34, height: 34, borderRadius: 9, flexShrink: 0,
        background: iconBg || (danger ? "rgba(255,77,103,0.12)" : "rgba(255,255,255,0.06)"),
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <Icon size={15} color={danger ? "#FF4D67" : iconColor} />
      </div>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: 13, fontWeight: 600, color: danger ? "#FF4D67" : "white", letterSpacing: -0.2 }}>{label}</p>
        {sub && <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>{sub}</p>}
      </div>
      {rightEl || (
        <>
          {value && <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>{value}</span>}
          {hasArrow && <ChevronRight size={14} color="rgba(255,255,255,0.2)" />}
        </>
      )}
    </button>
  );
}

function SettingGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ padding: "0 16px", marginBottom: 8 }}>
      <p style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.3)", letterSpacing: 0.8, marginBottom: 4, paddingLeft: 0 }}>
        {title}
      </p>
      <div style={{
        background: "rgba(26,32,53,0.6)", border: "1px solid rgba(255,255,255,0.05)",
        borderRadius: 16, padding: "0 14px",
      }}>
        {children}
      </div>
    </div>
  );
}

function Divider() {
  return <div style={{ height: 1, background: "rgba(255,255,255,0.05)", marginLeft: 46 }} />;
}

export function SettingsScreen() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState(true);
  const [biometric, setBiometric] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [aiAlerts, setAiAlerts] = useState(true);
  const [priceAlerts, setPriceAlerts] = useState(false);

  return (
    <div style={{ background: "#0A0E1A" }}>
      {/* Header */}
      <div style={{ padding: "16px 20px 16px" }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: -0.6 }}>Settings</h2>
      </div>

      {/* Profile Card */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "linear-gradient(135deg, rgba(26,32,53,0.9), rgba(20,26,45,0.9))",
          border: "1px solid rgba(255,255,255,0.07)", borderRadius: 20, padding: "16px",
          display: "flex", alignItems: "center", gap: 14,
        }}>
          <div style={{
            width: 54, height: 54, borderRadius: 16,
            background: "linear-gradient(135deg, #00D4AA, #00A882)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 20, fontWeight: 800, color: "#0A0E1A", flexShrink: 0,
          }}>
            {USER.initials}
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 16, fontWeight: 800, color: "white", letterSpacing: -0.4 }}>{USER.name}</p>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{USER.email}</p>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6 }}>
              <CheckCircle size={12} color="#00D4AA" />
              <span style={{ fontSize: 11, color: "#00D4AA", fontWeight: 600 }}>KYC Doğrulandı</span>
              <span style={{ width: 3, height: 3, borderRadius: "50%", background: "rgba(255,255,255,0.2)", display: "inline-block" }} />
              <span style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>Üye: {USER.memberSince}</span>
            </div>
          </div>
          <ChevronRight size={16} color="rgba(255,255,255,0.3)" />
        </div>

        {/* Portfolio Stats */}
        <div style={{
          display: "flex", gap: 0,
          background: "rgba(26,32,53,0.4)", border: "1px solid rgba(255,255,255,0.05)",
          borderRadius: 14, marginTop: 10, padding: "12px 16px",
        }}>
          {[
            { label: "Portföy", val: `₺${(PORTFOLIO_SUMMARY.totalValue / 1000).toFixed(0)}K` },
            { label: "Kâr/Zarar", val: `+%${PORTFOLIO_SUMMARY.totalGainPct.toFixed(1)}` },
            { label: "Risk Profili", val: USER.riskProfile },
          ].map((s, i) => (
            <div key={s.label} style={{
              flex: 1, textAlign: "center",
              borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.06)" : "none",
            }}>
              <p style={{ fontSize: 14, fontWeight: 800, color: i === 1 ? "#00D4AA" : "white" }}>{s.val}</p>
              <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Account Settings */}
      <SettingGroup title="HESAP">
        <SettingItem icon={User} iconColor="#6366F1" label="Profil Bilgileri" sub="Ad, telefon, adres" />
        <Divider />
        <SettingItem icon={Shield} iconColor="#F5A623" label="KYC Doğrulama" sub="Kimlik doğrulama tamamlandı" value="✓" hasArrow={false} rightEl={
          <span style={{ background: "rgba(0,212,170,0.1)", color: "#00D4AA", fontSize: 10, fontWeight: 700, borderRadius: 5, padding: "2px 8px" }}>
            Aktif
          </span>
        } />
        <Divider />
        <SettingItem icon={FileText} iconColor="#00D4AA" label="Banka Hesabı" sub="Ödeme yöntemlerini yönet" />
      </SettingGroup>

      {/* Security */}
      <SettingGroup title="GÜVENLİK">
        <SettingItem
          icon={Fingerprint} iconColor="#00D4AA"
          label="Biyometrik Giriş"
          sub="Face ID / Parmak izi"
          hasArrow={false}
          rightEl={<ToggleSwitch on={biometric} onToggle={() => setBiometric(!biometric)} />}
        />
        <Divider />
        <SettingItem icon={Eye} iconColor="#6366F1" label="Şifre Değiştir" sub="Son değişiklik: 3 ay önce" />
        <Divider />
        <SettingItem icon={Shield} iconColor="#F5A623" label="2FA Doğrulama" sub="SMS ile doğrulama aktif" />
      </SettingGroup>

      {/* Notifications */}
      <SettingGroup title="BİLDİRİMLER">
        <SettingItem
          icon={Bell} iconColor="#00D4AA"
          label="Push Bildirimleri"
          hasArrow={false}
          rightEl={<ToggleSwitch on={notifications} onToggle={() => setNotifications(!notifications)} />}
        />
        <Divider />
        <SettingItem
          icon={Zap} iconColor="#F5A623"
          label="AI Sinyalleri"
          sub="Al/Sat önerileri"
          hasArrow={false}
          rightEl={<ToggleSwitch on={aiAlerts} onToggle={() => setAiAlerts(!aiAlerts)} />}
        />
        <Divider />
        <SettingItem
          icon={AlertCircle} iconColor="#6366F1"
          label="Fiyat Alarmları"
          sub="Hedef fiyat bildirimleri"
          hasArrow={false}
          rightEl={<ToggleSwitch on={priceAlerts} onToggle={() => setPriceAlerts(!priceAlerts)} />}
        />
      </SettingGroup>

      {/* Appearance */}
      <SettingGroup title="GÖRÜNÜM">
        <SettingItem
          icon={Moon} iconColor="#6366F1"
          label="Karanlık Mod"
          hasArrow={false}
          rightEl={<ToggleSwitch on={darkMode} onToggle={() => setDarkMode(!darkMode)} />}
        />
        <Divider />
        <SettingItem icon={Globe} iconColor="#00D4AA" label="Dil / Language" value="Türkçe" />
        <Divider />
        <SettingItem icon={Palette} iconColor="#EC4899" label="Tema Rengi" value="Teal" />
      </SettingGroup>

      {/* Help */}
      <SettingGroup title="DESTEK">
        <SettingItem icon={HelpCircle} iconColor="#F5A623" label="Yardım Merkezi" />
        <Divider />
        <SettingItem icon={FileText} iconColor="#6366F1" label="Gizlilik Politikası" />
        <Divider />
        <SettingItem icon={FileText} iconColor="#94A3B8" label="Kullanım Koşulları" />
      </SettingGroup>

      {/* Tools */}
      <SettingGroup title="ARAÇLAR">
        <SettingItem
          icon={StickyNote} iconColor="#F5A623"
          label="Notlarım"
          sub="Yatırım notları ve hatırlatıcılar"
          onPress={() => navigate("/app/notes")}
        />
        <Divider />
        <SettingItem
          icon={Award} iconColor="#6366F1"
          label="Benchmark Karşılaştırma"
          sub="Portföyünüzü endekslerle karşılaştırın"
          onPress={() => navigate("/app/benchmark")}
        />
        <Divider />
        <SettingItem
          icon={LayoutGrid} iconColor="#00D4AA"
          label="Design System"
          sub="VAULTIQ bileşen kütüphanesi"
          onPress={() => navigate("/app/components")}
        />
      </SettingGroup>

      {/* App Info */}
      <div style={{ padding: "8px 16px 8px", textAlign: "center" }}>
        <p style={{ fontSize: 11, color: "rgba(255,255,255,0.2)" }}>VAULTIQ v2.4.1 • Build 2024.03</p>
      </div>

      {/* Logout */}
      <div style={{ padding: "0 16px 32px" }}>
        <button
          onClick={() => navigate("/splash")}
          style={{
            width: "100%", height: 48, borderRadius: 14,
            background: "rgba(255,77,103,0.08)", border: "1px solid rgba(255,77,103,0.18)",
            color: "#FF4D67", fontWeight: 700, fontSize: 14, cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}
        >
          <LogOut size={16} />
          Çıkış Yap
        </button>
      </div>
    </div>
  );
}