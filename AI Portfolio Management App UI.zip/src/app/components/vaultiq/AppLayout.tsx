import { Outlet, useNavigate, useLocation } from "react-router";
import { Home, PieChart, Sparkles, BarChart2, User, Newspaper } from "lucide-react";

const NAV_ITEMS = [
  { path: "/app", label: "Home", icon: Home },
  { path: "/app/portfolio", label: "Portföy", icon: PieChart },
  { path: "/app/sentiment", label: "Duygu", icon: Newspaper },
  { path: "/app/insights", label: "AI", icon: Sparkles },
  { path: "/app/settings", label: "Profil", icon: User },
];

export function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/app") return location.pathname === "/app";
    return location.pathname.startsWith(path);
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      {/* Scrollable content */}
      <div
        className="no-scrollbar"
        style={{ flex: 1, overflowY: "auto", overflowX: "hidden" }}
      >
        <Outlet />
      </div>

      {/* Bottom Navigation */}
      <div
        style={{
          height: 72,
          flexShrink: 0,
          background: "rgba(10,14,26,0.97)",
          backdropFilter: "blur(20px)",
          borderTop: "1px solid rgba(255,255,255,0.06)",
          display: "flex",
          alignItems: "stretch",
        }}
      >
        {NAV_ITEMS.map(({ path, label, icon: Icon }) => {
          const active = isActive(path);
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 3,
                background: "none",
                border: "none",
                cursor: "pointer",
                position: "relative",
                padding: "4px 0",
              }}
            >
              {/* Active indicator dot at top */}
              {active && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    width: 28,
                    height: 2,
                    borderRadius: "0 0 2px 2px",
                    background: "#00D4AA",
                    boxShadow: "0 2px 8px rgba(0,212,170,0.5)",
                  }}
                />
              )}

              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: active ? "rgba(0,212,170,0.1)" : "transparent",
                  transition: "all 0.2s",
                }}
              >
                <Icon
                  size={20}
                  color={active ? "#00D4AA" : "rgba(255,255,255,0.3)"}
                  strokeWidth={active ? 2 : 1.5}
                />
              </div>

              <span
                style={{
                  fontSize: 10,
                  fontWeight: active ? 600 : 400,
                  color: active ? "#00D4AA" : "rgba(255,255,255,0.3)",
                  letterSpacing: 0.2,
                  lineHeight: 1,
                }}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}