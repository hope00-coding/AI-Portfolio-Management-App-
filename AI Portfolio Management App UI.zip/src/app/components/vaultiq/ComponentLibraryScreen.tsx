import { useState } from "react";
import { useNavigate } from "react-router";
import {
  ArrowLeft, Zap, TrendingUp, TrendingDown, AlertTriangle,
  Info, Home, PieChart, BarChart2, Sparkles, User,
  CheckCircle, Search, Bell,
} from "lucide-react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";

const SPARK = [0.1, 0.4, 0.3, 0.6, 0.5, 0.8, 0.7, 1.0].map((v, i) => ({ i, v: v * 100 }));

// ─── Section wrapper ──────────────────────────────────────────────────────────
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <p style={{
        fontSize: 10, fontWeight: 800, color: "rgba(255,255,255,0.3)",
        letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 12,
        paddingLeft: 16,
      }}>
        {title}
      </p>
      <div style={{ padding: "0 16px" }}>{children}</div>
    </div>
  );
}

// ─── Badge ─────────────────────────────────────────────────────────────────────
function Badge({ label, color, bg, border }: { label: string; color: string; bg: string; border: string }) {
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      background: bg, border: `1px solid ${border}`,
      borderRadius: 8, padding: "3px 9px",
    }}>
      <div style={{ width: 5, height: 5, borderRadius: "50%", background: color }} />
      <span style={{ fontSize: 10, fontWeight: 700, color, letterSpacing: 0.4 }}>{label}</span>
    </div>
  );
}

export function ComponentLibraryScreen() {
  const navigate = useNavigate();
  const [inputFocus, setInputFocus] = useState(false);
  const [inputError, setInputError] = useState(false);
  const [inputVal, setInputVal] = useState("");
  const [sheetOpen, setSheetOpen] = useState(false);

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px 16px" }}>
        <button
          onClick={() => navigate(-1)}
          style={{
            width: 36, height: 36, borderRadius: 11, display: "flex",
            alignItems: "center", justifyContent: "center",
            background: "rgba(255,255,255,0.06)", border: "none", cursor: "pointer",
          }}
        >
          <ArrowLeft size={16} color="white" />
        </button>
        <div>
          <h2 style={{ fontSize: 18, fontWeight: 800, color: "white", letterSpacing: -0.5 }}>Design System</h2>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>VAULTIQ Component Library</p>
        </div>
      </div>

      {/* ── BUTTONS ──────────────────────────────────────── */}
      <Section title="Buttons">
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {/* Primary */}
          <button style={{
            width: "100%", height: 50, borderRadius: 14, border: "none", cursor: "pointer",
            background: "linear-gradient(135deg, #00D4AA, #00A882)",
            color: "#0A0E1A", fontWeight: 800, fontSize: 14, letterSpacing: 0.2,
            boxShadow: "0 6px 20px rgba(0,212,170,0.35)",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
          }}>
            <CheckCircle size={16} />
            Primary Button
          </button>

          {/* Secondary */}
          <button style={{
            width: "100%", height: 50, borderRadius: 14, cursor: "pointer",
            background: "rgba(0,212,170,0.1)",
            border: "1.5px solid rgba(0,212,170,0.3)",
            color: "#00D4AA", fontWeight: 700, fontSize: 14,
            display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
          }}>
            <TrendingUp size={16} />
            Secondary Button
          </button>

          {/* Ghost */}
          <button style={{
            width: "100%", height: 50, borderRadius: 14, cursor: "pointer",
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "rgba(255,255,255,0.65)", fontWeight: 600, fontSize: 14,
            display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
          }}>
            Ghost Button
          </button>

          {/* Danger */}
          <button style={{
            width: "100%", height: 50, borderRadius: 14, cursor: "pointer",
            background: "rgba(255,77,103,0.1)",
            border: "1.5px solid rgba(255,77,103,0.3)",
            color: "#FF4D67", fontWeight: 700, fontSize: 14,
            display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
          }}>
            <TrendingDown size={16} />
            Danger Button
          </button>
        </div>
      </Section>

      {/* ── INPUT FIELDS ─────────────────────────────────── */}
      <Section title="Input Fields">
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {/* Default */}
          <div>
            <label style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
              DEFAULT
            </label>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, height: 46, borderRadius: 12,
              background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
              padding: "0 14px",
            }}>
              <Search size={14} color="rgba(255,255,255,0.3)" />
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.3)" }}>Fon ara...</span>
            </div>
          </div>

          {/* Focused */}
          <div>
            <label style={{ fontSize: 11, fontWeight: 600, color: "#00D4AA", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
              FOCUSED
            </label>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, height: 46, borderRadius: 12,
              background: "rgba(0,212,170,0.05)", border: "1.5px solid rgba(0,212,170,0.4)",
              padding: "0 14px",
              boxShadow: "0 0 0 3px rgba(0,212,170,0.08)",
            }}>
              <Search size={14} color="#00D4AA" />
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>GTE</span>
              <div style={{ width: 1.5, height: 16, background: "#00D4AA", animation: "blink 1s infinite" }} />
            </div>
          </div>

          {/* Error */}
          <div>
            <label style={{ fontSize: 11, fontWeight: 600, color: "#FF4D67", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
              ERROR
            </label>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, height: 46, borderRadius: 12,
              background: "rgba(255,77,103,0.05)", border: "1.5px solid rgba(255,77,103,0.4)",
              padding: "0 14px",
            }}>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>Geçersiz miktar</span>
            </div>
            <p style={{ fontSize: 11, color: "#FF4D67", marginTop: 4 }}>⚠ Lütfen geçerli bir miktar girin</p>
          </div>
        </div>
      </Section>

      {/* ── BADGES / CHIPS ─────────────────────���─────────── */}
      <Section title="Badges & Chips">
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          <Badge label="Pozitif" color="#00D4AA" bg="rgba(0,212,170,0.12)" border="rgba(0,212,170,0.25)" />
          <Badge label="Negatif" color="#FF4D67" bg="rgba(255,77,103,0.12)" border="rgba(255,77,103,0.25)" />
          <Badge label="Nötr" color="rgba(255,255,255,0.6)" bg="rgba(255,255,255,0.07)" border="rgba(255,255,255,0.12)" />
          <Badge label="AI" color="#6366F1" bg="rgba(99,102,241,0.12)" border="rgba(99,102,241,0.25)" />
          <Badge label="Uyarı" color="#F5A623" bg="rgba(245,166,35,0.12)" border="rgba(245,166,35,0.25)" />
          <Badge label="%73 GÜVEN" color="#00D4AA" bg="rgba(0,212,170,0.12)" border="rgba(0,212,170,0.2)" />
        </div>
      </Section>

      {/* ── ASSET ROW CARD ───────────────────────────────── */}
      <Section title="Asset Row Card">
        {[
          { code: "GTE", name: "Garanti Portföy BIST Teknoloji", cat: "Hisse Senedi", val: "₺92,248", chg: "+1.45%", pos: true, color: "#6366F1" },
          { code: "XAU", name: "Fiziki Altın", cat: "Kıymetli Metal · 11.76g", val: "₺38,229", chg: "+0.92%", pos: true, color: "#F5A623" },
          { code: "FBK", name: "Fiba Portföy Karma Fonu", cat: "Karma", val: "₺57,825", chg: "-0.34%", pos: false, color: "#EC4899" },
        ].map((row) => (
          <div
            key={row.code}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              background: "rgba(26,32,53,0.65)", border: "1px solid rgba(255,255,255,0.055)",
              borderRadius: 14, padding: "11px 14px", marginBottom: 6,
            }}
          >
            <div style={{
              width: 40, height: 40, borderRadius: 12, flexShrink: 0,
              background: `${row.color}18`, border: `1.5px solid ${row.color}35`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 9, fontWeight: 900, color: row.color,
            }}>
              {row.code}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: "white", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{row.name}</p>
              <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{row.cat}</p>
            </div>
            <div style={{ textAlign: "right" }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: "white" }}>{row.val}</p>
              <p style={{ fontSize: 11, fontWeight: 700, color: row.pos ? "#00D4AA" : "#FF4D67", marginTop: 2 }}>{row.chg}</p>
            </div>
          </div>
        ))}
      </Section>

      {/* ── AI INSIGHT CARD ──────────────────────────────── */}
      <Section title="AI Insight Card">
        <div style={{
          background: "linear-gradient(135deg, rgba(0,212,170,0.07), rgba(99,102,241,0.05))",
          border: "1px solid rgba(0,212,170,0.2)", borderRadius: 18, padding: "14px 16px",
          position: "relative", overflow: "hidden",
        }}>
          <div style={{
            position: "absolute", top: -20, right: -20, width: 100, height: 100, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(0,212,170,0.12) 0%, transparent 70%)",
            pointerEvents: "none",
          }} />
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10, flexShrink: 0,
              background: "rgba(0,212,170,0.15)", border: "1px solid rgba(0,212,170,0.2)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Zap size={16} color="#00D4AA" />
            </div>
            <div>
              <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 3 }}>
                <span style={{ fontSize: 10, color: "#00D4AA", fontWeight: 800, letterSpacing: 0.8 }}>AI INSIGHT</span>
                <div style={{ background: "rgba(0,212,170,0.15)", borderRadius: 4, padding: "1px 5px" }}>
                  <span style={{ fontSize: 9, fontWeight: 800, color: "#00D4AA" }}>%73 GÜVEN</span>
                </div>
              </div>
              <p style={{ fontSize: 13, fontWeight: 700, color: "white" }}>GTE için Alış Sinyali</p>
            </div>
          </div>
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", lineHeight: 1.5, paddingLeft: 46 }}>
            BIST Teknoloji endeksi güçlü momentum gösteriyor. AI %73 olasılıkla yükseliş öngörüyor.
          </p>
        </div>
      </Section>

      {/* ── CHART CARD ───────────────────────────────────── */}
      <Section title="Chart Card Container">
        <div style={{
          background: "rgba(26,32,53,0.7)", border: "1px solid rgba(255,255,255,0.07)",
          borderRadius: 20, padding: "16px 16px 0", overflow: "hidden",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div>
              <p style={{ fontSize: 10, color: "rgba(255,255,255,0.38)", fontWeight: 600, letterSpacing: 0.8 }}>TOPLAM PORTFÖY</p>
              <p style={{ fontSize: 24, fontWeight: 900, color: "white", letterSpacing: -1 }}>₺485.320</p>
            </div>
            <div style={{
              display: "flex", alignItems: "center", gap: 4,
              background: "rgba(0,212,170,0.12)", border: "1px solid rgba(0,212,170,0.25)",
              borderRadius: 8, padding: "4px 10px",
            }}>
              <TrendingUp size={12} color="#00D4AA" />
              <span style={{ fontSize: 12, fontWeight: 700, color: "#00D4AA" }}>+0.88%</span>
            </div>
          </div>
          <div style={{ height: 80, marginLeft: -16, marginRight: -16, position: "relative" }}>
            {/* Hidden SVG gradient def outside recharts */}
            <svg width="0" height="0" style={{ position: "absolute" }}>
              <defs>
                <linearGradient id="clGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00D4AA" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#00D4AA" stopOpacity={0} />
                </linearGradient>
              </defs>
            </svg>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={SPARK} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                <Area type="monotone" dataKey="v" stroke="#00D4AA" strokeWidth={2.5} fill="url(#clGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </Section>

      {/* ── BOTTOM NAV ───────────────────────────────────── */}
      <Section title="Bottom Navigation Bar">
        <div style={{
          background: "rgba(10,14,26,0.97)", borderRadius: 18,
          border: "1px solid rgba(255,255,255,0.06)",
          display: "flex", alignItems: "stretch", height: 68,
        }}>
          {[
            { icon: Home, label: "Home", active: true },
            { icon: PieChart, label: "Portföy", active: false },
            { icon: BarChart2, label: "Markets", active: false },
            { icon: Sparkles, label: "AI", active: false },
            { icon: User, label: "Profil", active: false },
          ].map(({ icon: Icon, label, active }) => (
            <div
              key={label}
              style={{
                flex: 1, display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center", gap: 3,
                position: "relative",
              }}
            >
              {active && (
                <div style={{
                  position: "absolute", top: 0, width: 24, height: 2,
                  borderRadius: "0 0 2px 2px", background: "#00D4AA",
                  boxShadow: "0 2px 8px rgba(0,212,170,0.6)",
                }} />
              )}
              <div style={{
                width: 34, height: 34, borderRadius: 10, display: "flex",
                alignItems: "center", justifyContent: "center",
                background: active ? "rgba(0,212,170,0.1)" : "transparent",
              }}>
                <Icon size={18} color={active ? "#00D4AA" : "rgba(255,255,255,0.3)"} strokeWidth={active ? 2 : 1.5} />
              </div>
              <span style={{ fontSize: 9, fontWeight: active ? 700 : 400, color: active ? "#00D4AA" : "rgba(255,255,255,0.3)" }}>
                {label}
              </span>
            </div>
          ))}
        </div>
      </Section>

      {/* ── MODAL / BOTTOM SHEET ─────────────────────────── */}
      <Section title="Modal / Bottom Sheet">
        <button
          onClick={() => setSheetOpen(true)}
          style={{
            width: "100%", height: 46, borderRadius: 13, border: "1px solid rgba(255,255,255,0.1)",
            background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.65)",
            fontSize: 13, fontWeight: 600, cursor: "pointer",
          }}
        >
          Bottom Sheet Örneğini Göster ↑
        </button>
      </Section>

      <div style={{ height: 32 }} />

      {/* Inline Sheet Demo */}
      {sheetOpen && (
        <>
          <div
            onClick={() => setSheetOpen(false)}
            style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 80, backdropFilter: "blur(4px)" }}
          />
          <div style={{
            position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 90,
            background: "#111827", borderRadius: "24px 24px 0 0",
            border: "1px solid rgba(255,255,255,0.08)",
            boxShadow: "0 -20px 60px rgba(0,0,0,0.7)",
            padding: "0 20px 36px",
          }}>
            <div style={{ display: "flex", justifyContent: "center", padding: "12px 0 16px" }}>
              <div style={{ width: 36, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.15)" }} />
            </div>
            <p style={{ fontSize: 16, fontWeight: 800, color: "white", marginBottom: 6 }}>Bottom Sheet</p>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", lineHeight: 1.5, marginBottom: 20 }}>
              Bu bir modal/bottom sheet örneğidir. Karanlık overlay + cam efekti + yuvarlatılmış köşeler ile tasarlanmıştır.
            </p>
            <div style={{ display: "flex", gap: 10 }}>
              <button
                onClick={() => setSheetOpen(false)}
                style={{
                  flex: 1, height: 46, borderRadius: 12,
                  background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                  color: "rgba(255,255,255,0.6)", fontWeight: 600, fontSize: 13, cursor: "pointer",
                }}
              >
                Kapat
              </button>
              <button
                onClick={() => setSheetOpen(false)}
                style={{
                  flex: 2, height: 46, borderRadius: 12, border: "none",
                  background: "linear-gradient(135deg, #00D4AA, #00A882)",
                  color: "#0A0E1A", fontWeight: 800, fontSize: 13, cursor: "pointer",
                  boxShadow: "0 4px 16px rgba(0,212,170,0.3)",
                }}
              >
                Onayla
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}