import { useState } from "react";
import { useNavigate } from "react-router";
import { Eye, EyeOff, Fingerprint, ShieldCheck } from "lucide-react";

export function LoginScreen() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<"login" | "register">("login");
  const [showPass, setShowPass] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const inputStyle: React.CSSProperties = {
    width: "100%",
    height: 50,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 12,
    padding: "0 14px",
    color: "white",
    fontSize: 14,
    outline: "none",
    boxSizing: "border-box",
  };

  return (
    <div
      className="flex flex-col h-full no-scrollbar"
      style={{ background: "#0A0E1A", overflowY: "auto" }}
    >
      {/* Header */}
      <div style={{ padding: "28px 28px 24px" }}>
        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 10,
              background: "linear-gradient(135deg, #00D4AA, #00A882)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <svg width="18" height="18" viewBox="0 0 36 36" fill="none">
              <rect x="6" y="8" width="24" height="20" rx="3" stroke="white" strokeWidth="2.5" fill="none" />
              <circle cx="18" cy="18" r="5" stroke="white" strokeWidth="2" fill="none" />
              <circle cx="18" cy="18" r="2" fill="white" />
            </svg>
          </div>
          <span style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: -0.8 }}>
            VAULT<span style={{ color: "#00D4AA" }}>IQ</span>
          </span>
        </div>

        <h1
          style={{
            fontSize: 26,
            fontWeight: 800,
            color: "white",
            letterSpacing: -0.8,
            marginBottom: 6,
          }}
        >
          {tab === "login" ? "Welcome back" : "Create account"}
        </h1>
        <p style={{ fontSize: 14, color: "rgba(255,255,255,0.45)" }}>
          {tab === "login"
            ? "Sign in to access your portfolio"
            : "Start managing smarter today"}
        </p>
      </div>

      {/* Tab Switcher */}
      <div style={{ padding: "0 28px 24px" }}>
        <div
          style={{
            display: "flex",
            background: "rgba(255,255,255,0.05)",
            borderRadius: 12,
            padding: 4,
          }}
        >
          {(["login", "register"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                flex: 1,
                height: 38,
                borderRadius: 9,
                border: "none",
                cursor: "pointer",
                fontSize: 14,
                fontWeight: 600,
                transition: "all 0.2s",
                background: tab === t ? "#00D4AA" : "transparent",
                color: tab === t ? "#0A0E1A" : "rgba(255,255,255,0.45)",
              }}
            >
              {t === "login" ? "Log In" : "Register"}
            </button>
          ))}
        </div>
      </div>

      {/* Form */}
      <div style={{ padding: "0 28px", flex: 1 }}>
        <div className="flex flex-col gap-3">
          {tab === "register" && (
            <div>
              <label style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", fontWeight: 600, letterSpacing: 0.5, display: "block", marginBottom: 6 }}>
                FULL NAME
              </label>
              <input
                type="text"
                placeholder="Ahmet Yılmaz"
                value={name}
                onChange={(e) => setName(e.target.value)}
                style={inputStyle}
              />
            </div>
          )}

          <div>
            <label style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", fontWeight: 600, letterSpacing: 0.5, display: "block", marginBottom: 6 }}>
              EMAIL
            </label>
            <input
              type="email"
              placeholder="ornek@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
            />
          </div>

          {tab === "register" && (
            <div>
              <label style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", fontWeight: 600, letterSpacing: 0.5, display: "block", marginBottom: 6 }}>
                PHONE
              </label>
              <input
                type="tel"
                placeholder="+90 5XX XXX XX XX"
                style={inputStyle}
              />
            </div>
          )}

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", fontWeight: 600, letterSpacing: 0.5 }}>
                PASSWORD
              </label>
              {tab === "login" && (
                <button
                  style={{ background: "none", border: "none", color: "#00D4AA", fontSize: 12, cursor: "pointer", fontWeight: 500 }}
                >
                  Forgot Password?
                </button>
              )}
            </div>
            <div style={{ position: "relative" }}>
              <input
                type={showPass ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ ...inputStyle, paddingRight: 44 }}
              />
              <button
                onClick={() => setShowPass(!showPass)}
                style={{
                  position: "absolute",
                  right: 14,
                  top: "50%",
                  transform: "translateY(-50%)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  color: "rgba(255,255,255,0.35)",
                  display: "flex",
                  padding: 0,
                }}
              >
                {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {tab === "register" && (
            <div>
              <label style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", fontWeight: 600, letterSpacing: 0.5, display: "block", marginBottom: 6 }}>
                CONFIRM PASSWORD
              </label>
              <input type="password" placeholder="••••••••" style={inputStyle} />
            </div>
          )}

          {tab === "register" && (
            <div className="flex gap-2 items-start mt-1">
              <div
                style={{
                  width: 18,
                  height: 18,
                  borderRadius: 5,
                  border: "1px solid #00D4AA",
                  background: "rgba(0,212,170,0.15)",
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 1,
                }}
              >
                <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                  <path d="M1 4L3.5 7L9 1" stroke="#00D4AA" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </div>
              <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", lineHeight: 1.5 }}>
                I agree to the{" "}
                <span style={{ color: "#00D4AA" }}>Terms of Service</span> and{" "}
                <span style={{ color: "#00D4AA" }}>Privacy Policy</span>
              </span>
            </div>
          )}

          {/* Main CTA */}
          <button
            onClick={() => navigate("/app")}
            style={{
              width: "100%",
              height: 52,
              borderRadius: 14,
              background: "linear-gradient(135deg, #00D4AA 0%, #00A882 100%)",
              color: "#0A0E1A",
              fontWeight: 700,
              fontSize: 16,
              border: "none",
              cursor: "pointer",
              boxShadow: "0 8px 24px rgba(0,212,170,0.3)",
              letterSpacing: -0.3,
              marginTop: 4,
            }}
          >
            {tab === "login" ? "Log In" : "Create Account"}
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 my-1">
            <div style={{ flex: 1, height: 1, background: "rgba(255,255,255,0.07)" }} />
            <span style={{ fontSize: 12, color: "rgba(255,255,255,0.25)", fontWeight: 500 }}>OR</span>
            <div style={{ flex: 1, height: 1, background: "rgba(255,255,255,0.07)" }} />
          </div>

          {/* Google Login */}
          <button
            style={{
              width: "100%",
              height: 50,
              borderRadius: 14,
              background: "rgba(255,255,255,0.04)",
              color: "rgba(255,255,255,0.8)",
              fontWeight: 600,
              fontSize: 14,
              border: "1px solid rgba(255,255,255,0.08)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
            }}
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M18.17 10.23c0-.67-.06-1.32-.17-1.95H10v3.69h4.58a3.91 3.91 0 01-1.7 2.57v2.13h2.75c1.61-1.48 2.54-3.67 2.54-6.44z" fill="#4285F4" />
              <path d="M10 19c2.3 0 4.23-.76 5.64-2.06l-2.75-2.13c-.76.51-1.74.81-2.89.81-2.22 0-4.1-1.5-4.77-3.51H2.4v2.2A8.5 8.5 0 0010 19z" fill="#34A853" />
              <path d="M5.23 12.11A5.1 5.1 0 014.96 10c0-.73.13-1.44.37-2.11V5.7H2.4A8.5 8.5 0 001.5 10c0 1.37.33 2.66.9 3.8l2.83-1.69z" fill="#FBBC05" />
              <path d="M10 4.98c1.25 0 2.37.43 3.25 1.27l2.44-2.44C14.22 2.44 12.3 1.5 10 1.5A8.5 8.5 0 002.4 5.7l2.83 2.19C5.9 6.48 7.78 4.98 10 4.98z" fill="#EA4335" />
            </svg>
            Continue with Google
          </button>

          {/* Biometric */}
          {tab === "login" && (
            <button
              style={{
                width: "100%",
                height: 50,
                borderRadius: 14,
                background: "rgba(0,212,170,0.06)",
                color: "#00D4AA",
                fontWeight: 600,
                fontSize: 14,
                border: "1px solid rgba(0,212,170,0.15)",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 10,
              }}
            >
              <Fingerprint size={20} />
              Sign in with Face ID / Fingerprint
            </button>
          )}
        </div>
      </div>

      {/* Privacy Shield Badge */}
      <div style={{ padding: "16px 28px 8px" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          background: "linear-gradient(135deg, rgba(0,212,170,0.08), rgba(0,212,170,0.04))",
          border: "1px solid rgba(0,212,170,0.2)",
          borderRadius: 14, padding: "12px 14px",
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10, flexShrink: 0,
            background: "rgba(0,212,170,0.12)", border: "1px solid rgba(0,212,170,0.25)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <ShieldCheck size={18} color="#00D4AA" />
          </div>
          <div>
            <p style={{ fontSize: 11, fontWeight: 800, color: "#00D4AA", letterSpacing: 0.2, marginBottom: 2 }}>
              Gizlilik Öncelikli
            </p>
            <p style={{ fontSize: 10, color: "rgba(255,255,255,0.5)", lineHeight: 1.5 }}>
              %100 Yerel İşlem. Banka kimlik bilgileriniz hiçbir zaman saklanmaz veya iletilmez.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom safe area */}
      <div style={{ height: 12 }} />
    </div>
  );
}
