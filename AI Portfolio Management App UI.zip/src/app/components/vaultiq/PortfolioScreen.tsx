import { useState } from "react";
import { useNavigate } from "react-router";
import { TrendingUp, TrendingDown, ChevronRight, RefreshCw, Plus } from "lucide-react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis } from "recharts";
import { HOLDINGS, PORTFOLIO_SUMMARY, MONTHLY_RETURNS, fmt, fmtCurrency } from "./data";
import { AddTransactionSheet } from "./AddTransactionSheet";

const PERF_TABS = ["1G", "1H", "1A", "1Y"] as const;
type PerfTab = typeof PERF_TABS[number];

const PERF_MAP: Record<PerfTab, keyof (typeof HOLDINGS)[0]> = {
  "1G": "dayChange",
  "1H": "monthChange",
  "1A": "monthChange",
  "1Y": "ytdChange",
};

function PieTooltip({ active, payload }: any) {
  if (active && payload?.length) {
    const d = payload[0].payload;
    return (
      <div style={{ background: "#1A2035", border: "1px solid rgba(0,212,170,0.3)", borderRadius: 8, padding: "6px 10px" }}>
        <p style={{ color: "white", fontSize: 11, fontWeight: 600 }}>{d.name}</p>
        <p style={{ color: "#00D4AA", fontSize: 12, fontWeight: 700 }}>%{d.allocation.toFixed(1)}</p>
      </div>
    );
  }
  return null;
}

export function PortfolioScreen() {
  const [perfTab, setPerfTab] = useState<PerfTab>("1A");
  const [showFunds, setShowFunds] = useState(true);
  const [sheetOpen, setSheetOpen] = useState(false);
  const navigate = useNavigate();

  const { totalValue, totalGain, totalGainPct, todayChange, todayChangePct } = PORTFOLIO_SUMMARY;
  const funds = HOLDINGS.filter((h) => h.type === "fund");
  const metals = HOLDINGS.filter((h) => h.type === "metal");

  const pieData = HOLDINGS.map((h) => ({
    name: h.code,
    value: h.value,
    allocation: h.allocation,
    color: h.color,
  }));

  const perfKey = PERF_MAP[perfTab];

  return (
    <div style={{ background: "#0A0E1A" }}>
      {/* Header */}
      <div style={{ padding: "16px 20px 12px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: -0.6 }}>Portfolio</h2>
        <button style={{
          background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 9, width: 34, height: 34, display: "flex", alignItems: "center",
          justifyContent: "center", cursor: "pointer",
        }}>
          <RefreshCw size={14} color="rgba(255,255,255,0.6)" />
        </button>
      </div>

      {/* Total Value Summary */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "linear-gradient(135deg, rgba(26,32,53,0.9), rgba(20,26,45,0.9))",
          border: "1px solid rgba(255,255,255,0.07)", borderRadius: 20, padding: "20px",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
            <div>
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", fontWeight: 600, letterSpacing: 0.5 }}>PORTFÖY DEĞERİ</p>
              <p style={{ fontSize: 30, fontWeight: 800, color: "white", letterSpacing: -1.2, marginTop: 4 }}>
                ₺{fmt(totalValue)}
              </p>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 4, justifyContent: "flex-end",
                background: "rgba(0,212,170,0.1)", border: "1px solid rgba(0,212,170,0.2)",
                borderRadius: 8, padding: "4px 10px", marginBottom: 4,
              }}>
                <TrendingUp size={12} color="#00D4AA" />
                <span style={{ color: "#00D4AA", fontSize: 13, fontWeight: 700 }}>+{todayChangePct.toFixed(2)}%</span>
              </div>
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Bugün {fmtCurrency(todayChange)}</p>
            </div>
          </div>

          {/* Stats row */}
          <div style={{ display: "flex", gap: 0 }}>
            {[
              { label: "Maliyet", value: `₺${fmt(totalValue - totalGain, 0)}` },
              { label: "Toplam Kâr", value: `+₺${fmt(totalGain, 0)}` },
              { label: "Kâr %", value: `+%${totalGainPct.toFixed(1)}` },
            ].map((s, i) => (
              <div key={s.label} style={{ flex: 1, borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.08)" : "none", paddingLeft: i > 0 ? 12 : 0 }}>
                <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginBottom: 3 }}>{s.label}</p>
                <p style={{ fontSize: 13, fontWeight: 700, color: i > 0 ? "#00D4AA" : "white", letterSpacing: -0.3 }}>{s.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Allocation Donut Chart */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "rgba(26,32,53,0.6)", border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: 20, padding: "16px",
        }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "white", marginBottom: 12, letterSpacing: -0.3 }}>
            Dağılım
          </h3>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {/* Donut chart */}
            <div style={{ width: 110, height: 110, flexShrink: 0, position: "relative" }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%" cy="50%"
                    innerRadius={32} outerRadius={50}
                    paddingAngle={2}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {pieData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<PieTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              {/* Center text */}
              <div style={{
                position: "absolute", top: "50%", left: "50%",
                transform: "translate(-50%, -50%)", textAlign: "center",
              }}>
                <p style={{ fontSize: 8, color: "rgba(255,255,255,0.4)", letterSpacing: 0.3 }}>VARLIK</p>
                <p style={{ fontSize: 12, fontWeight: 800, color: "white" }}>{HOLDINGS.length}</p>
              </div>
            </div>

            {/* Legend */}
            <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 5 }}>
              {HOLDINGS.slice(0, 5).map((h) => (
                <div key={h.id} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: h.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 10, color: "rgba(255,255,255,0.6)", flex: 1 }}>{h.code}</span>
                  <span style={{ fontSize: 10, fontWeight: 600, color: "white" }}>%{h.allocation.toFixed(1)}</span>
                </div>
              ))}
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: 2, background: "rgba(255,255,255,0.2)", flexShrink: 0 }} />
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", flex: 1 }}>Diğer</span>
                <span style={{ fontSize: 10, fontWeight: 600, color: "white" }}>%{(100 - HOLDINGS.slice(0,5).reduce((a,b) => a + b.allocation,0)).toFixed(1)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Returns Bar Chart */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "rgba(26,32,53,0.6)", border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: 20, padding: "16px",
        }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "white", marginBottom: 12, letterSpacing: -0.3 }}>
            Aylık Getiri
          </h3>
          <div style={{ height: 80 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MONTHLY_RETURNS} margin={{ top: 0, right: 0, left: -32, bottom: 0 }} barSize={12}>
                <XAxis dataKey="month" tick={{ fontSize: 9, fill: "rgba(255,255,255,0.3)" }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Bar dataKey="value" radius={[3, 3, 0, 0]}>
                  {MONTHLY_RETURNS.map((entry, index) => (
                    <Cell key={`bar-cell-${index}`} fill={entry.value >= 0 ? "#00D4AA" : "#FF4D67"} fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Funds Tab + List */}
      <div style={{ padding: "0 16px" }}>
        {/* Section toggles */}
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          {[["Fonlar", true], ["Metaller", false]].map(([label, isFunds]) => (
            <button
              key={String(label)}
              onClick={() => setShowFunds(Boolean(isFunds))}
              style={{
                height: 32, paddingLeft: 14, paddingRight: 14, borderRadius: 9, border: "none", cursor: "pointer",
                fontSize: 12, fontWeight: 600,
                background: showFunds === Boolean(isFunds) ? "#00D4AA" : "rgba(255,255,255,0.06)",
                color: showFunds === Boolean(isFunds) ? "#0A0E1A" : "rgba(255,255,255,0.5)",
              }}
            >
              {String(label)}
            </button>
          ))}

          <div style={{ flex: 1 }} />
          {/* Perf tab */}
          <div style={{ display: "flex", gap: 3, background: "rgba(255,255,255,0.04)", borderRadius: 9, padding: 2 }}>
            {PERF_TABS.map((t) => (
              <button
                key={t}
                onClick={() => setPerfTab(t)}
                style={{
                  height: 24, paddingLeft: 6, paddingRight: 6, borderRadius: 7, border: "none", cursor: "pointer",
                  fontSize: 10, fontWeight: 600,
                  background: perfTab === t ? "rgba(0,212,170,0.2)" : "transparent",
                  color: perfTab === t ? "#00D4AA" : "rgba(255,255,255,0.3)",
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="flex flex-col gap-2 pb-6">
          {(showFunds ? funds : metals).map((h) => {
            const perfValue = h[perfKey] as number;
            const isPos = perfValue >= 0;
            return (
              <div
                key={h.id}
                onClick={() => navigate(`/app/asset/${h.id}`)}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  background: "rgba(26,32,53,0.6)",
                  border: "1px solid rgba(255,255,255,0.05)",
                  borderRadius: 14, padding: "12px 14px", cursor: "pointer",
                }}
              >
                <div style={{
                  width: 40, height: 40, borderRadius: 11, flexShrink: 0,
                  background: `${h.color}18`,
                  border: `1.5px solid ${h.color}35`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 10, fontWeight: 800, color: h.color, letterSpacing: -0.3,
                }}>
                  {h.code}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 12, fontWeight: 600, color: "white", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {h.name}
                  </p>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 3 }}>
                    <span style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>{h.category}</span>
                    {/* Risk dots */}
                    <div style={{ display: "flex", gap: 2 }}>
                      {[1,2,3,4,5].map((i) => (
                        <div key={i} style={{ width: 5, height: 5, borderRadius: "50%",
                          background: i <= (h.risk ?? 3) ? "#F5A623" : "rgba(255,255,255,0.1)" }} />
                      ))}
                    </div>
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ fontSize: 13, fontWeight: 700, color: "white" }}>₺{fmt(h.value, 0)}</p>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 3, marginTop: 3 }}>
                    {isPos ? <TrendingUp size={10} color="#00D4AA" /> : <TrendingDown size={10} color="#FF4D67" />}
                    <span style={{ fontSize: 11, fontWeight: 600, color: isPos ? "#00D4AA" : "#FF4D67" }}>
                      {isPos ? "+" : ""}{perfValue.toFixed(2)}%
                    </span>
                  </div>
                </div>
                <ChevronRight size={14} color="rgba(255,255,255,0.2)" />
              </div>
            );
          })}
        </div>
      </div>

      {/* FAB */}
      <button
        onClick={() => setSheetOpen(true)}
        style={{
          position: "absolute", bottom: 80, right: 20,
          width: 50, height: 50, borderRadius: 16,
          background: "linear-gradient(135deg, #00D4AA, #00A882)",
          border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 8px 24px rgba(0,212,170,0.4)",
          zIndex: 20,
        }}
      >
        <Plus size={22} color="#0A0E1A" strokeWidth={2.5} />
      </button>

      {/* Add Transaction Sheet */}
      <AddTransactionSheet open={sheetOpen} onClose={() => setSheetOpen(false)} />
    </div>
  );
}