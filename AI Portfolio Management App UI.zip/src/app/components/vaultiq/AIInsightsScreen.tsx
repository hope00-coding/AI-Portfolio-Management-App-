import { useState } from "react";
import { useNavigate } from "react-router";
import { Zap, TrendingUp, TrendingDown, AlertTriangle, Info, ChevronRight, Brain, Sparkles, Award, ChevronLeft, ChevronRight as ChevronRightIcon } from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";
import { AI_INSIGHTS, HOLDINGS, STRESS_SCENARIOS, PORTFOLIO_SUMMARY } from "./data";

const RISK_DATA = [
  { axis: "Hisse\nRiski", value: 65 },
  { axis: "Faiz\nRiski", value: 40 },
  { axis: "Kur\nRiski", value: 55 },
  { axis: "Likidite", value: 80 },
  { axis: "Volatilite", value: 48 },
  { axis: "Konsantrasyon", value: 35 },
];

const TYPE_CONFIG = {
  buy: { icon: TrendingUp, color: "#00D4AA", bg: "rgba(0,212,170,0.1)", border: "rgba(0,212,170,0.2)", label: "AL" },
  sell: { icon: TrendingDown, color: "#FF4D67", bg: "rgba(255,77,103,0.1)", border: "rgba(255,77,103,0.2)", label: "SAT" },
  alert: { icon: AlertTriangle, color: "#F5A623", bg: "rgba(245,166,35,0.1)", border: "rgba(245,166,35,0.2)", label: "UYARI" },
  info: { icon: Info, color: "#6366F1", bg: "rgba(99,102,241,0.1)", border: "rgba(99,102,241,0.2)", label: "BİLGİ" },
};

const FILTER_TABS = ["Tümü", "Al", "Sat", "Uyarı"] as const;

// ─── Stress Test Section ──────────────────────────────────────────────────────
function StressTestSection() {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const scenario = STRESS_SCENARIOS[selectedIdx];
  const portfolioValue = PORTFOLIO_SUMMARY.totalValue;
  const impactAmount = portfolioValue * (scenario.impact / 100);

  return (
    <div style={{ padding: "0 16px 16px" }}>
      <div style={{
        background: "rgba(26,32,53,0.7)", border: "1px solid rgba(255,255,255,0.06)",
        borderRadius: 20, padding: 16,
      }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 8,
            background: "rgba(245,166,35,0.12)", border: "1px solid rgba(245,166,35,0.2)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <span style={{ fontSize: 13 }}>⚡</span>
          </div>
          <div>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: "white", letterSpacing: -0.3 }}>
              Tarihsel Stres Testi
            </h3>
            <p style={{ fontSize: 10, color: "rgba(255,255,255,0.38)" }}>Monte Carlo Simülasyonu</p>
          </div>
        </div>

        {/* Carousel navigation */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <button
            onClick={() => setSelectedIdx((i) => Math.max(0, i - 1))}
            style={{
              width: 28, height: 28, borderRadius: 8, flexShrink: 0,
              background: selectedIdx === 0 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)",
              border: "1px solid rgba(255,255,255,0.08)", cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
            disabled={selectedIdx === 0}
          >
            <ChevronLeft size={14} color={selectedIdx === 0 ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.6)"} />
          </button>

          {/* Scenario tabs */}
          <div className="no-scrollbar" style={{ flex: 1, display: "flex", gap: 5, overflowX: "auto" }}>
            {STRESS_SCENARIOS.map((s, i) => (
              <button
                key={s.id}
                onClick={() => setSelectedIdx(i)}
                style={{
                  flexShrink: 0,
                  height: 26,
                  paddingLeft: 9, paddingRight: 9,
                  borderRadius: 7, border: "none", cursor: "pointer",
                  fontSize: 9.5, fontWeight: 700,
                  background: selectedIdx === i ? "rgba(245,166,35,0.15)" : "rgba(255,255,255,0.04)",
                  color: selectedIdx === i ? "#F5A623" : "rgba(255,255,255,0.4)",
                  transition: "all 0.2s",
                  whiteSpace: "nowrap",
                }}
              >
                {s.date}
              </button>
            ))}
          </div>

          <button
            onClick={() => setSelectedIdx((i) => Math.min(STRESS_SCENARIOS.length - 1, i + 1))}
            style={{
              width: 28, height: 28, borderRadius: 8, flexShrink: 0,
              background: selectedIdx === STRESS_SCENARIOS.length - 1 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)",
              border: "1px solid rgba(255,255,255,0.08)", cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
            disabled={selectedIdx === STRESS_SCENARIOS.length - 1}
          >
            <ChevronRightIcon size={14} color={selectedIdx === STRESS_SCENARIOS.length - 1 ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.6)"} />
          </button>
        </div>

        {/* Scenario Info */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: "white" }}>{scenario.name}</span>
            <span style={{
              background: scenario.severity === "Felaket" ? "rgba(255,77,103,0.15)" :
                scenario.severity === "Kritik" ? "rgba(255,77,103,0.12)" :
                  scenario.severity === "Yüksek" ? "rgba(245,166,35,0.12)" : "rgba(245,166,35,0.1)",
              color: scenario.severity === "Felaket" || scenario.severity === "Kritik" ? "#FF4D67" : "#F5A623",
              fontSize: 9, fontWeight: 800, borderRadius: 4, padding: "2px 6px", letterSpacing: 0.4,
            }}>
              {scenario.severity.toUpperCase()}
            </span>
          </div>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", lineHeight: 1.55 }}>
            {scenario.description}
          </p>
        </div>

        {/* Drawdown Impact Card */}
        <div style={{
          background: scenario.impact < -30
            ? "linear-gradient(135deg, rgba(255,77,103,0.12), rgba(255,77,103,0.06))"
            : scenario.impact < -20
              ? "linear-gradient(135deg, rgba(245,166,35,0.12), rgba(245,166,35,0.05))"
              : "linear-gradient(135deg, rgba(245,166,35,0.08), rgba(255,77,103,0.06))",
          border: `1px solid ${scenario.impact < -25 ? "rgba(255,77,103,0.25)" : "rgba(245,166,35,0.2)"}`,
          borderRadius: 14, padding: "14px 16px", marginBottom: 12,
        }}>
          <p style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", fontWeight: 600, letterSpacing: 0.5, marginBottom: 6, textTransform: "uppercase" }}>
            Portföy Drawdown Etkisi
          </p>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 8 }}>
            <span style={{
              fontSize: 32, fontWeight: 900, letterSpacing: -1.5,
              color: scenario.impact < -25 ? "#FF4D67" : "#F5A623",
            }}>
              {scenario.impact.toFixed(1)}%
            </span>
            <span style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.5)" }}>
              ≈ ₺{Math.abs(impactAmount / 1000).toFixed(0)}K kayıp
            </span>
          </div>

          {/* Asset breakdown */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
            {[
              { label: "TEFAS Fonları", val: scenario.details.funds },
              { label: "Altın", val: scenario.details.gold },
              { label: "Gümüş", val: scenario.details.silver },
              { label: "Platin", val: scenario.details.platinum },
            ].map((row) => (
              <div key={row.label} style={{
                background: "rgba(0,0,0,0.15)", borderRadius: 8, padding: "7px 10px",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.45)" }}>{row.label}</span>
                <span style={{
                  fontSize: 11, fontWeight: 800,
                  color: row.val >= 0 ? "#00D4AA" : "#FF4D67",
                }}>
                  {row.val >= 0 ? "+" : ""}{row.val.toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Scenario dots */}
        <div style={{ display: "flex", justifyContent: "center", gap: 5 }}>
          {STRESS_SCENARIOS.map((_, i) => (
            <button
              key={i}
              onClick={() => setSelectedIdx(i)}
              style={{
                width: i === selectedIdx ? 16 : 6, height: 6,
                borderRadius: 3, border: "none", cursor: "pointer",
                background: i === selectedIdx ? "#F5A623" : "rgba(255,255,255,0.15)",
                transition: "all 0.25s",
                padding: 0,
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export function AIInsightsScreen() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState("Tümü");
  const [expandedId, setExpandedId] = useState<string | null>("1");

  const filtered = AI_INSIGHTS.filter((i) => {
    if (filter === "Tümü") return true;
    if (filter === "Al") return i.type === "buy";
    if (filter === "Sat") return i.type === "sell";
    if (filter === "Uyarı") return i.type === "alert";
    return true;
  });

  return (
    <div style={{ background: "#0A0E1A" }}>
      {/* Header */}
      <div style={{ padding: "16px 20px 12px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 9,
            background: "linear-gradient(135deg, #00D4AA, #00A882)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Brain size={16} color="#0A0E1A" />
          </div>
          <div style={{ flex: 1 }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: -0.6 }}>AI Insights</h2>
          </div>
          {/* Benchmark shortcut */}
          <button
            onClick={() => navigate("/app/benchmark")}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: "rgba(0,212,170,0.1)", border: "1px solid rgba(0,212,170,0.2)",
              borderRadius: 9, padding: "5px 10px", cursor: "pointer",
            }}
          >
            <Award size={12} color="#00D4AA" />
            <span style={{ fontSize: 10, fontWeight: 700, color: "#00D4AA" }}>Benchmark</span>
          </button>
        </div>
        <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", lineHeight: 1.5 }}>
          AI modelimiz portföyünüzü sürekli analiz ediyor.
        </p>
      </div>

      {/* AI Score Card */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "linear-gradient(135deg, rgba(0,212,170,0.08) 0%, rgba(99,102,241,0.06) 100%)",
          border: "1px solid rgba(0,212,170,0.15)", borderRadius: 20, padding: "16px 20px",
          display: "flex", alignItems: "center", gap: 16,
        }}>
          <div style={{ position: "relative" }}>
            <svg width="72" height="72" viewBox="0 0 72 72">
              <circle cx="36" cy="36" r="30" stroke="rgba(255,255,255,0.06)" strokeWidth="6" fill="none" />
              <circle
                cx="36" cy="36" r="30"
                stroke="url(#scoreGrad)" strokeWidth="6" fill="none"
                strokeDasharray={`${2 * Math.PI * 30 * 0.78} ${2 * Math.PI * 30 * 0.22}`}
                strokeDashoffset={2 * Math.PI * 30 * 0.25}
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#00D4AA" />
                  <stop offset="100%" stopColor="#6366F1" />
                </linearGradient>
              </defs>
            </svg>
            <div style={{
              position: "absolute", top: "50%", left: "50%",
              transform: "translate(-50%, -50%)", textAlign: "center",
            }}>
              <p style={{ fontSize: 18, fontWeight: 800, color: "white", lineHeight: 1 }}>78</p>
              <p style={{ fontSize: 8, color: "rgba(255,255,255,0.4)", letterSpacing: 0.5 }}>SKOR</p>
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
              <span style={{ fontSize: 16, fontWeight: 800, color: "white" }}>İyi Portföy</span>
              <span style={{
                background: "rgba(0,212,170,0.15)", color: "#00D4AA",
                fontSize: 10, fontWeight: 700, borderRadius: 6, padding: "2px 7px",
              }}>
                Dengeli
              </span>
            </div>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 1.5, marginBottom: 8 }}>
              Portföyünüz iyi çeşitlendirilmiş. 3 aktif sinyal var.
            </p>
            <div style={{ display: "flex", gap: 12 }}>
              {[
                { label: "Aktif Sinyal", val: "3" },
                { label: "Uyarı", val: "1" },
              ].map((s) => (
                <div key={s.label}>
                  <p style={{ fontSize: 16, fontWeight: 800, color: "#00D4AA" }}>{s.val}</p>
                  <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Risk Radar */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{
          background: "rgba(26,32,53,0.6)", border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: 20, padding: "16px",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: "white", letterSpacing: -0.3 }}>Risk Analizi</h3>
            <span style={{
              background: "rgba(245,166,35,0.12)", color: "#F5A623",
              fontSize: 10, fontWeight: 700, borderRadius: 6, padding: "2px 8px",
            }}>
              ORTA RİSK
            </span>
          </div>
          <div style={{ height: 160 }}>
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={RISK_DATA} cx="50%" cy="50%" outerRadius={55}>
                <PolarGrid stroke="rgba(255,255,255,0.06)" />
                <PolarAngleAxis
                  dataKey="axis"
                  tick={{ fontSize: 8, fill: "rgba(255,255,255,0.4)" }}
                />
                <Radar
                  dataKey="value"
                  stroke="#00D4AA"
                  fill="#00D4AA"
                  fillOpacity={0.1}
                  strokeWidth={1.5}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          {/* Risk metrics */}
          <div style={{ display: "flex", gap: 0, borderTop: "1px solid rgba(255,255,255,0.05)", paddingTop: 10 }}>
            {[
              { label: "Sharpe", val: "1.42" },
              { label: "Beta", val: "0.87" },
              { label: "Volatilite", val: "%12.3" },
              { label: "Max Kayıp", val: "-%8.4" },
            ].map((m, i) => (
              <div key={m.label} style={{
                flex: 1, textAlign: "center",
                borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.06)" : "none",
              }}>
                <p style={{ fontSize: 13, fontWeight: 700, color: "white" }}>{m.val}</p>
                <p style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{m.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stress Test Simulator */}
      <StressTestSection />

      {/* Filters */}
      <div style={{ padding: "0 16px 12px", display: "flex", gap: 6 }}>
        {FILTER_TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            style={{
              height: 30, paddingLeft: 12, paddingRight: 12, borderRadius: 8, border: "none", cursor: "pointer",
              fontSize: 11, fontWeight: 600,
              background: filter === tab ? "#00D4AA" : "rgba(255,255,255,0.05)",
              color: filter === tab ? "#0A0E1A" : "rgba(255,255,255,0.45)",
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* AI Disclaimer Banner */}
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          background: "rgba(99,102,241,0.07)", border: "1px solid rgba(99,102,241,0.18)",
          borderRadius: 10, padding: "8px 12px",
        }}>
          <span style={{ fontSize: 12, flexShrink: 0 }}>⚠️</span>
          <p style={{ fontSize: 10, color: "rgba(255,255,255,0.45)", lineHeight: 1.5 }}>
            <span style={{ color: "rgba(99,102,241,0.9)", fontWeight: 700 }}>Yalnızca eğitim & karar desteği amaçlıdır.</span>{" "}
            Lisanslı finansal tavsiye değildir. Yatırım kararlarınızı kendi araştırmanıza dayandırın.
          </p>
        </div>
      </div>

      {/* Insights List */}
      <div style={{ padding: "0 16px 24px" }} className="flex flex-col gap-3">
        {filtered.map((insight) => {
          const cfg = TYPE_CONFIG[insight.type as keyof typeof TYPE_CONFIG];
          const IconComp = cfg.icon;
          const isExpanded = expandedId === insight.id;
          const holding = HOLDINGS.find((h) => h.id === insight.asset);

          return (
            <div
              key={insight.id}
              style={{
                background: "rgba(26,32,53,0.7)",
                border: `1px solid ${isExpanded ? cfg.border : "rgba(255,255,255,0.06)"}`,
                borderRadius: 16,
                overflow: "hidden",
                transition: "border-color 0.2s",
              }}
            >
              {/* Card Header */}
              <div
                onClick={() => setExpandedId(isExpanded ? null : insight.id)}
                style={{ padding: "14px 16px", cursor: "pointer", display: "flex", gap: 12, alignItems: "flex-start" }}
              >
                <div style={{
                  width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                  background: cfg.bg, display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  <IconComp size={16} color={cfg.color} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                    <span style={{
                      background: cfg.bg, color: cfg.color, fontSize: 9, fontWeight: 800,
                      borderRadius: 4, padding: "2px 6px", letterSpacing: 0.5,
                    }}>
                      {cfg.label}
                    </span>
                    <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>{insight.time}</span>
                  </div>
                  <p style={{ fontSize: 13, fontWeight: 700, color: "white", lineHeight: 1.3 }}>
                    {insight.title}
                  </p>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                  <div style={{
                    background: "rgba(255,255,255,0.06)", borderRadius: 6, padding: "3px 7px",
                  }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: cfg.color }}>%{insight.confidence}</span>
                  </div>
                  <ChevronRight
                    size={14} color="rgba(255,255,255,0.25)"
                    style={{ transform: isExpanded ? "rotate(90deg)" : "none", transition: "transform 0.2s" }}
                  />
                </div>
              </div>

              {/* Expanded content */}
              {isExpanded && (
                <div style={{ padding: "0 16px 14px" }}>
                  <p style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", lineHeight: 1.6, marginBottom: 12 }}>
                    {insight.body}
                  </p>

                  {/* Asset info */}
                  {holding && (
                    <div style={{
                      background: "rgba(255,255,255,0.04)", borderRadius: 10,
                      padding: "10px 12px", display: "flex", justifyContent: "space-between",
                      alignItems: "center", marginBottom: 12,
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{
                          width: 28, height: 28, borderRadius: 7,
                          background: `${holding.color}20`, border: `1px solid ${holding.color}35`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 8, fontWeight: 800, color: holding.color,
                        }}>
                          {holding.code}
                        </div>
                        <div>
                          <p style={{ fontSize: 11, color: "white", fontWeight: 600 }}>{holding.name.split(" ").slice(0,3).join(" ")}</p>
                          <p style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>Mevcut değer: ₺{(holding.value / 1000).toFixed(1)}K</p>
                        </div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <p style={{ fontSize: 13, fontWeight: 700, color: holding.dayChange >= 0 ? "#00D4AA" : "#FF4D67" }}>
                          {holding.dayChange >= 0 ? "+" : ""}{holding.dayChange.toFixed(2)}%
                        </p>
                        <p style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", marginTop: 1 }}>bugün</p>
                      </div>
                    </div>
                  )}

                  {/* Confidence bar */}
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)" }}>Model Güveni</span>
                      <span style={{ fontSize: 10, fontWeight: 700, color: cfg.color }}>%{insight.confidence}</span>
                    </div>
                    <div style={{ height: 4, background: "rgba(255,255,255,0.08)", borderRadius: 2 }}>
                      <div style={{
                        height: "100%", width: `${insight.confidence}%`,
                        background: `linear-gradient(90deg, ${cfg.color}88, ${cfg.color})`,
                        borderRadius: 2, transition: "width 0.6s ease",
                      }} />
                    </div>
                  </div>

                  <button
                    onClick={() => navigate(`/app/asset/${insight.asset}`)}
                    style={{
                      width: "100%", height: 38, borderRadius: 10,
                      background: cfg.bg, border: `1px solid ${cfg.border}`,
                      color: cfg.color, fontWeight: 700, fontSize: 12,
                      cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    }}
                  >
                    <Sparkles size={14} />
                    Varlığı Görüntüle
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}