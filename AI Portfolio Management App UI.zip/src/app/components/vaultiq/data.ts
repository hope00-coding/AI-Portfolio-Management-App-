// ─── VAULTIQ Mock Data ────────────────────────────────────────────────────────

export const USER = {
  name: "Ahmet Yılmaz",
  initials: "AY",
  email: "ahmet.yilmaz@example.com",
  phone: "+90 532 123 45 67",
  riskProfile: "Dengeli",
  memberSince: "Mart 2023",
};

// ─── Portfolio Summary ─────────────────────────────────────────────────────────
export const PORTFOLIO_SUMMARY = {
  totalValue: 485320.48,
  totalCost: 412890.0,
  totalGain: 72430.48,
  totalGainPct: 17.54,
  todayChange: 4231.15,
  todayChangePct: 0.88,
};

// ─── Chart Data ───────────────────────────────────────────────────────────────
function genPoints(base: number, target: number, count: number, volatility = 0.008): number[] {
  const arr: number[] = [];
  let val = base;
  for (let i = 0; i < count; i++) {
    const trend = (target - val) / (count - i);
    val = val + trend + (Math.random() - 0.45) * val * volatility;
    arr.push(Math.round(val));
  }
  arr[arr.length - 1] = target;
  return arr;
}

const _c1D = genPoints(477000, 485320, 24, 0.003);
const _c1H = genPoints(467000, 485320, 7, 0.01);
const _c1A = genPoints(451000, 485320, 30, 0.008);
const _c3A = genPoints(415000, 485320, 12, 0.012);
const _c1Y = genPoints(320000, 485320, 12, 0.02);

export const CHART_DATA: Record<string, { time: string; value: number }[]> = {
  "1G": Array.from({ length: 24 }, (_, i) => ({
    time: `${String(i).padStart(2, "0")}:00`,
    value: _c1D[i],
  })),
  "1H": Array.from({ length: 7 }, (_, i) => ({
    time: ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"][i],
    value: _c1H[i],
  })),
  "1A": Array.from({ length: 30 }, (_, i) => ({
    time: `${i + 1}`,
    value: _c1A[i],
  })),
  "3A": Array.from({ length: 12 }, (_, i) => ({
    time: `H${i + 1}`,
    value: _c3A[i],
  })),
  "1Y": Array.from({ length: 12 }, (_, i) => ({
    time: ["Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara", "Oca", "Şub"][i],
    value: _c1Y[i],
  })),
};

// ─── Holdings ─────────────────────────────────────────────────────────────────
export const HOLDINGS = [
  {
    id: "IPP",
    name: "İş Portföy Para Piyasası Fonu",
    code: "IPP",
    type: "fund",
    category: "Para Piyasası",
    nav: 0.110342,
    units: 1_002_450,
    value: 110_588.34,
    cost: 98_400.0,
    dayChange: 0.032,
    monthChange: 0.97,
    ytdChange: 11.8,
    color: "#00D4AA",
    allocation: 22.8,
    risk: 1,
    manager: "İş Portföy Yönetimi A.Ş.",
  },
  {
    id: "GTE",
    name: "Garanti Portföy BIST Teknoloji",
    code: "GTE",
    type: "fund",
    category: "Hisse Senedi",
    nav: 46.124,
    units: 2_000,
    value: 92_248.0,
    cost: 71_200.0,
    dayChange: 1.45,
    monthChange: 8.3,
    ytdChange: 42.1,
    color: "#6366F1",
    allocation: 19.0,
    risk: 5,
    manager: "Garanti Portföy Yönetimi A.Ş.",
  },
  {
    id: "AKE",
    name: "Ak Portföy Eurobond Fonu",
    code: "AKE",
    type: "fund",
    category: "Borçlanma Araçları",
    nav: 8.524,
    units: 10_000,
    value: 85_240.0,
    cost: 78_300.0,
    dayChange: 0.12,
    monthChange: 2.1,
    ytdChange: 15.2,
    color: "#F59E0B",
    allocation: 17.6,
    risk: 2,
    manager: "Ak Portföy Yönetimi A.Ş.",
  },
  {
    id: "YAK",
    name: "Yapı Kredi Portföy Altın Fonu",
    code: "YAK",
    type: "fund",
    category: "Altın/Kıymetli Maden",
    nav: 126.482,
    units: 600,
    value: 75_889.2,
    cost: 61_200.0,
    dayChange: 0.78,
    monthChange: 3.4,
    ytdChange: 28.5,
    color: "#EAB308",
    allocation: 15.6,
    risk: 3,
    manager: "Yapı Kredi Portföy Yönetimi A.Ş.",
  },
  {
    id: "FBK",
    name: "Fiba Portföy Karma Fonu",
    code: "FBK",
    type: "fund",
    category: "Karma",
    nav: 5.7825,
    units: 10_000,
    value: 57_825.0,
    cost: 52_100.0,
    dayChange: -0.34,
    monthChange: 1.8,
    ytdChange: 22.3,
    color: "#EC4899",
    allocation: 12.0,
    risk: 3,
    manager: "Fiba Portföy Yönetimi A.Ş.",
  },
  {
    id: "GOLD",
    name: "Fiziki Altın",
    code: "XAU",
    type: "metal",
    category: "Kıymetli Metal",
    nav: 3250.8,
    units: 11.76,
    value: 38_229.41,
    cost: 28_900.0,
    dayChange: 0.92,
    monthChange: 4.5,
    ytdChange: 31.2,
    color: "#F5A623",
    allocation: 7.9,
    risk: 3,
    unit: "gram",
    manager: "—",
  },
  {
    id: "SILVER",
    name: "Fiziki Gümüş",
    code: "XAG",
    type: "metal",
    category: "Kıymetli Metal",
    nav: 38.92,
    units: 380.0,
    value: 14_789.6,
    cost: 11_200.0,
    dayChange: 1.23,
    monthChange: 6.2,
    ytdChange: 18.4,
    color: "#94A3B8",
    allocation: 3.1,
    risk: 4,
    unit: "gram",
    manager: "—",
  },
  {
    id: "PLAT",
    name: "Fiziki Platin",
    code: "XPT",
    type: "metal",
    category: "Kıymetli Metal",
    nav: 1175.5,
    units: 8.64,
    value: 10_156.32,
    cost: 9_200.0,
    dayChange: -0.45,
    monthChange: 2.1,
    ytdChange: 10.5,
    color: "#CBD5E1",
    allocation: 2.1,
    risk: 4,
    unit: "gram",
    manager: "—",
  },
];

// ─── Asset Detail Charts ───────────────────────────────────────────────────────
const _assetChartCache = new Map<string, number[]>();

export function getAssetChart(id: string, range: string) {
  const key = `${id}-${range}`;
  const ranges: Record<string, { count: number; base: number }> = {
    "1G": { count: 24, base: 0.98 },
    "1H": { count: 7, base: 0.93 },
    "1A": { count: 30, base: 0.88 },
    "3A": { count: 90, base: 0.78 },
    "1Y": { count: 12, base: 0.62 },
  };
  if (!_assetChartCache.has(key)) {
    const r = ranges[range] || ranges["1A"];
    const holding = HOLDINGS.find((h) => h.id === id);
    const target = holding?.nav ?? 100;
    const base = target * r.base;
    _assetChartCache.set(key, genPoints(base, target, r.count, 0.015));
  }
  const values = _assetChartCache.get(key)!;
  return values.map((v, i) => ({ i: i.toString(), v: parseFloat(v.toFixed(4)) }));
}

// ─── Fund Catalog (for Discover) ──────────────────────────────────────────────
export const FUND_CATALOG = [
  { id: "IPP", code: "IPP", name: "İş Portföy Para Piyasası", category: "Para Piyasası", nav: 0.1103, change: 0.032, risk: 1, aum: "8.2 Mia ₺", return1y: 11.8 },
  { id: "GTE", code: "GTE", name: "Garanti Portföy BIST Teknoloji", category: "Hisse Senedi", nav: 46.12, change: 1.45, risk: 5, aum: "2.1 Mia ₺", return1y: 42.1 },
  { id: "AKE", code: "AKE", name: "Ak Portföy Eurobond Fonu", category: "Borçlanma", nav: 8.52, change: 0.12, risk: 2, aum: "5.6 Mia ₺", return1y: 15.2 },
  { id: "YAK", code: "YAK", name: "Yapı Kredi Portföy Altın", category: "Altın", nav: 126.48, change: 0.78, risk: 3, aum: "3.4 Mia ₺", return1y: 28.5 },
  { id: "FBK", code: "FBK", name: "Fiba Portföy Karma Fonu", category: "Karma", nav: 5.78, change: -0.34, risk: 3, aum: "1.2 Mia ₺", return1y: 22.3 },
  { id: "TIE", code: "TIE", name: "TEB Portföy İkinci Hisse", category: "Hisse Senedi", nav: 12.34, change: 0.89, risk: 5, aum: "0.9 Mia ₺", return1y: 38.7 },
  { id: "DGH", code: "DGH", name: "Denizbank Portföy Gıda", category: "Hisse Senedi", nav: 23.15, change: -0.21, risk: 5, aum: "0.7 Mia ₺", return1y: 29.1 },
  { id: "ZMF", code: "ZMF", name: "Ziraat Portföy Metal Fonu", category: "Altın", nav: 88.4, change: 0.65, risk: 3, aum: "6.8 Mia ₺", return1y: 25.3 },
  { id: "HBM", code: "HBM", name: "Halk BES Borçlanma Fonu", category: "Borçlanma", nav: 2.18, change: 0.08, risk: 2, aum: "4.1 Mia ₺", return1y: 12.6 },
  { id: "VKP", code: "VKP", name: "Vakıf Portföy Karma Fonu", category: "Karma", nav: 15.92, change: 0.44, risk: 3, aum: "2.8 Mia ₺", return1y: 24.8 },
  { id: "QNB", code: "QNB", name: "QNB Finans Para Piyasası", category: "Para Piyasası", nav: 0.0921, change: 0.029, risk: 1, aum: "3.3 Mia ₺", return1y: 10.9 },
  { id: "TFX", code: "TFX", name: "Türkiye Finans Fon Sepeti", category: "Fon Sepeti", nav: 4.55, change: 0.31, risk: 3, aum: "1.5 Mia ₺", return1y: 19.4 },
];

// ─── AI Insights ──────────────────────────────────────────────────────────────
export const AI_INSIGHTS = [
  {
    id: "1",
    type: "buy",
    title: "GTE için Alış Sinyali",
    body: "BIST Teknoloji endeksi son 3 gündür güçlü momentum gösteriyor. Teknik analizde RSI 58 seviyesinde. AI modelimiz %73 olasılıkla kısa vadeli yükseliş öngörüyor.",
    asset: "GTE",
    confidence: 73,
    impact: "high",
    time: "2 saat önce",
  },
  {
    id: "2",
    type: "alert",
    title: "Portföy Denge Uyarısı",
    body: "Para piyasası fonunuzun ağırlığı (%22.8) hedef dağılımınızın üzerinde. Hisse senedi fonlarına %5 artış için rebalancing önerilir.",
    asset: "IPP",
    confidence: 89,
    impact: "medium",
    time: "5 saat önce",
  },
  {
    id: "3",
    type: "sell",
    title: "AKE Kâr Realizasyonu",
    body: "Eurobond fonunuz hedef getirisine ulaştı. Faiz oranı riskinden korunmak için pozisyonun %30'unu realize etmeyi değerlendirin.",
    asset: "AKE",
    confidence: 65,
    impact: "medium",
    time: "Dün",
  },
  {
    id: "4",
    type: "info",
    title: "Altın Fiyat Analizi",
    body: "USD/TRY kuru etkisiyle altın TRY bazında yükseliş trendinde. Fed toplantısı öncesinde güvenli liman talebi artıyor. Altın pozisyonunuzu koruyun.",
    asset: "GOLD",
    confidence: 81,
    impact: "low",
    time: "Dün",
  },
  {
    id: "5",
    type: "info",
    title: "Gümüş: Endüstriyel Talep",
    body: "Solar panel üretimindeki artış gümüş talebini destekliyor. Orta vadede gümüş fiyatlarında yükseliş bekleniyor.",
    asset: "SILVER",
    confidence: 68,
    impact: "low",
    time: "2 gün önce",
  },
];

// ─── Market Snapshot ──────────────────────────────────────────────────────────
export const MARKET_SNAPSHOT = [
  { label: "USD/TRY", value: "32.84", change: 0.31, icon: "🇺🇸" },
  { label: "EUR/TRY", value: "35.62", change: -0.12, icon: "🇪🇺" },
  { label: "Altın/gr", value: "₺3,250", change: 0.92, icon: "🥇" },
  { label: "Gümüş/gr", value: "₺38.92", change: 1.23, icon: "⚪" },
  { label: "BIST100", value: "8,842", change: 0.54, icon: "📈" },
  { label: "Platin/gr", value: "₺1,175", change: -0.45, icon: "🔘" },
];

// ─── Monthly Returns ──────────────────────────────────────────────────────────
export const MONTHLY_RETURNS = [
  { month: "Mar", value: 2.1 },
  { month: "Nis", value: -0.8 },
  { month: "May", value: 3.4 },
  { month: "Haz", value: 1.9 },
  { month: "Tem", value: 4.2 },
  { month: "Ağu", value: -1.2 },
  { month: "Eyl", value: 2.8 },
  { month: "Eki", value: 3.1 },
  { month: "Kas", value: -0.5 },
  { month: "Ara", value: 1.6 },
  { month: "Oca", value: 2.3 },
  { month: "Şub", value: 0.9 },
];

// ─── Benchmark Data ────────────────────────────────────────────────────────────
function genBenchmark(base: number, target: number, count: number, vol = 0.018) {
  const arr: number[] = [];
  let val = base;
  for (let i = 0; i < count; i++) {
    const trend = (target - val) / (count - i);
    val = val + trend + (Math.random() - 0.48) * val * vol;
    arr.push(parseFloat(val.toFixed(2)));
  }
  arr[arr.length - 1] = target;
  return arr;
}

const _bm_portfolio_1y = genBenchmark(100, 117.54, 12, 0.014);
const _bm_sp500_1y     = genBenchmark(100, 108.10, 12, 0.016);
const _bm_nasdaq_1y    = genBenchmark(100, 114.30, 12, 0.022);
const _bm_btc_1y       = genBenchmark(100, 134.20, 12, 0.055);
const _bm_gold_1y      = genBenchmark(100, 131.20, 12, 0.012);

const MONTHS_12 = ["Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara", "Oca", "Şub"];

function sliceBenchmarks(count: number) {
  return Array.from({ length: count }, (_, i) => ({
    time: MONTHS_12[MONTHS_12.length - count + i],
    portfolio: _bm_portfolio_1y[12 - count + i],
    sp500: _bm_sp500_1y[12 - count + i],
    nasdaq: _bm_nasdaq_1y[12 - count + i],
    btc: _bm_btc_1y[12 - count + i],
    gold: _bm_gold_1y[12 - count + i],
  }));
}

export const BENCHMARK_DATA: Record<string, ReturnType<typeof sliceBenchmarks>> = {
  "1A":  sliceBenchmarks(1),
  "3A":  sliceBenchmarks(3),
  "6A":  sliceBenchmarks(6),
  "1Y":  sliceBenchmarks(12),
};

export const BENCHMARK_STATS = {
  portfolio: { ret: "+17.54%", sharpe: "1.42", maxDD: "-8.4%" },
  sp500:     { ret: "+8.10%",  sharpe: "0.98", maxDD: "-11.2%" },
  nasdaq:    { ret: "+14.30%", sharpe: "1.15", maxDD: "-14.8%" },
  btc:       { ret: "+34.20%", sharpe: "0.72", maxDD: "-38.5%" },
  gold:      { ret: "+31.20%", sharpe: "1.08", maxDD: "-6.2%" },
};

// ─── Notes ─────────────────────────────────────────────────────────────────────
export const INITIAL_NOTES = [
  {
    id: "n1",
    title: "2025 Yatırım Hedefleri",
    date: "2 Mart 2025",
    preview: "Altın ağırlığını %35'e çıkar. Para piyasası fonlarını azalt...",
    tag: "Yatırım Planı",
    body: "Altın ağırlığını %35'e çıkar. Para piyasası fonlarını azalt ve hisse senedi fonlarına kaydır. Yıl sonu hedef portföy değeri: ₺600.000.",
  },
  {
    id: "n2",
    title: "Fed Toplantısı Notları",
    date: "28 Şubat 2025",
    preview: "Faiz indirimi beklentisi güçleniyor. Altın pozisyonunu koru...",
    tag: "Araştırma",
    body: "Faiz indirimi beklentisi güçleniyor. Altın pozisyonunu koru. USD/TRY volatilitesi artıyor, döviz riskinden korunmak için Eurobond ağırlığı artırılabilir.",
  },
  {
    id: "n3",
    title: "GTE Fon Analizi",
    date: "24 Şubat 2025",
    preview: "BIST Teknoloji endeksi güçlü. RSI 58. Kısa vadeli yükseliş...",
    tag: "Araştırma",
    body: "BIST Teknoloji endeksi güçlü seyrediyor. RSI 58 seviyesinde, henüz aşırı alım bölgesinde değil. Kısa vadeli yükseliş potansiyeli mevcut. 3 aylık hedef: %12 getiri.",
  },
  {
    id: "n4",
    title: "Rebalancing Hatırlatıcı",
    date: "15 Şubat 2025",
    preview: "Her çeyrek başında portföyü hedef dağılıma göre dengele...",
    tag: "Hatırlatıcı",
    body: "Her çeyrek başında portföyü hedef dağılıma göre dengele. Hedef: Fonlar %80, Altın %12, Gümüş %5, Platin %3. Sapma %5'i geçerse işlem yap.",
  },
];

export type Note = typeof INITIAL_NOTES[0];

// ─── Sentiment & News Data ────────────────────────────────────────────────────
export const FINBERT_SENTIMENT = {
  bullish: 62,
  neutral: 24,
  bearish: 14,
  label: "Yükseliş Eğilimli",
  updatedAt: "11:45 TSİ",
};

export const SENTIMENT_TWEETS = [
  {
    id: "t1",
    handle: "@TurkFinance",
    name: "Türk Finans",
    avatar: "TF",
    avatarColor: "#00D4AA",
    text: "BIST100 bugün güçlü bir yükselişle açıldı. TEFAS altın fonları yatırımcılarının sepetinde yer buluyor. #BIST #TEFAS",
    time: "14d",
    sentiment: "positive",
    score: 0.87,
  },
  {
    id: "t2",
    handle: "@InvestTR",
    name: "Yatırım TR",
    avatar: "YT",
    avatarColor: "#6366F1",
    text: "Fed toplantısı öncesinde altın fiyatları yeniden hareket kazandı. Güvenli liman talebi artıyor olabilir.",
    time: "2sa",
    sentiment: "positive",
    score: 0.74,
  },
  {
    id: "t3",
    handle: "@EkonomiAnaliz",
    name: "Ekonomi Analiz",
    avatar: "EA",
    avatarColor: "#F59E0B",
    text: "Enflasyon verisi beklentilerin üzerinde geldi. Para piyasası fonlarına olan ilgi artabilir. #Enflasyon #TRY",
    time: "3sa",
    sentiment: "neutral",
    score: 0.51,
  },
  {
    id: "t4",
    handle: "@BorsaGuru",
    name: "Borsa Guru",
    avatar: "BG",
    avatarColor: "#EC4899",
    text: "Kur baskısı devam ediyor. Döviz bazlı fonlarda dikkatli olunmalı. TRY volatilitesi sürüyor. #Dolar #TRY",
    time: "4sa",
    sentiment: "negative",
    score: 0.23,
  },
  {
    id: "t5",
    handle: "@GoldTurkey",
    name: "Gold Turkey",
    avatar: "GT",
    avatarColor: "#EAB308",
    text: "Fiziki altın talebinde yılın rekoru kırıldı. Gram altın 3.250 TL'yi aştı. Yükseliş devam edebilir. #Altın",
    time: "5sa",
    sentiment: "positive",
    score: 0.91,
  },
  {
    id: "t6",
    handle: "@RiskAnaliz",
    name: "Risk Analiz",
    avatar: "RA",
    avatarColor: "#94A3B8",
    text: "Portföy çeşitlendirmesi kritik önem taşıyor. Tek varlık sınıfına yoğunlaşmaktan kaçının. #Diversification",
    time: "6sa",
    sentiment: "neutral",
    score: 0.55,
  },
];

export const SENTIMENT_NEWS = [
  {
    id: "n1",
    headline: "TEFAS'ta Para Piyasası Fonları Rekora Koşuyor: Yatırımcılar Güvenli Limana Sığındı",
    source: "BloombergHT",
    time: "1sa önce",
    sentiment: "positive",
    summary: "Para piyasası fonlarına olan talep Kasım 2024'ten bu yana en yüksek seviyeye ulaştı.",
    category: "Fonlar",
  },
  {
    id: "n2",
    headline: "Merkez Bankası Faiz Kararı Açıklandı: Piyasalar Olumlu Karşıladı",
    source: "Reuters TR",
    time: "2sa önce",
    sentiment: "positive",
    summary: "TCMB'nin faiz kararı analistlerin beklentileriyle örtüştü, piyasalarda rahatlama hissedildi.",
    category: "Makro",
  },
  {
    id: "n3",
    headline: "Döviz Krizinin Gölgesi: USD/TRY Yeni Zirveleri Test Ediyor",
    source: "Dünya Gazetesi",
    time: "3sa önce",
    sentiment: "negative",
    summary: "Amerikan dolarının TRY karşısındaki değer kazanımı sürerken yatırımcılar tedirgin.",
    category: "Döviz",
  },
  {
    id: "n4",
    headline: "Altın Fiyatları Jeopolitik Gelişmelerle Yükselişte, Analistler İzliyor",
    source: "Finansal Haber",
    time: "4sa önce",
    sentiment: "positive",
    summary: "Global belirsizlik ortamında altın güvenli liman özelliğini korurken ons fiyatı $3,100'ı geçti.",
    category: "Emtia",
  },
  {
    id: "n5",
    headline: "BIST100 Teknik Görünüm: RSI Aşırı Alım Bölgesinde, Düzeltme Gelebilir",
    source: "TeknikAnaliz.com",
    time: "5sa önce",
    sentiment: "negative",
    summary: "Teknik göstergeler kısa vadede bir konsolidasyon ya da düzeltme dönemine işaret ediyor.",
    category: "Hisse",
  },
  {
    id: "n6",
    headline: "Gümüş Endüstriyel Talep: Solar Sektörü Güçlü Talep Yaratıyor",
    source: "Metal Haber",
    time: "6sa önce",
    sentiment: "positive",
    summary: "Yenilenebilir enerji yatırımlarındaki artış gümüş talebini desteklemeye devam ediyor.",
    category: "Emtia",
  },
  {
    id: "n7",
    headline: "Eurobond Piyasasında Görece Sakinlik, Türk Tahvilleri Yatay Seyretti",
    source: "Bond Market TR",
    time: "7sa önce",
    sentiment: "neutral",
    summary: "Eurobond fonları bugün yatay bir seyir izlerken, faiz risk priminde belirgin bir değişim gözlemlenmedi.",
    category: "Sabit Getiri",
  },
];

// ─── Stress Test Scenarios ────────────────────────────────────────────────────
export const STRESS_SCENARIOS = [
  {
    id: "s1",
    name: "2018 Döviz Krizi",
    date: "Ağu 2018",
    description: "USD/TRY %40 değer kazandı, BIST %30 düştü, altın TRY bazında yükseldi.",
    impact: -18.4,
    details: {
      funds: -24.2,
      gold: +31.5,
      silver: +18.2,
      platinum: -8.1,
    },
    color: "#FF4D67",
    severity: "Kritik",
  },
  {
    id: "s2",
    name: "COVID-19 Çöküşü",
    date: "Mar 2020",
    description: "Küresel piyasalar çöktü. BIST devre kesici mekanizmasını devreye aldı.",
    impact: -22.7,
    details: {
      funds: -28.5,
      gold: +8.3,
      silver: -15.4,
      platinum: -24.6,
    },
    color: "#F59E0B",
    severity: "Yüksek",
  },
  {
    id: "s3",
    name: "2021 Kara Çarşamba",
    date: "Kas 2021",
    description: "Merkez Bankası faiz indirimi sonrası TRY serbest düşüşe geçti, döviz dolarizasyonu arttı.",
    impact: -31.2,
    details: {
      funds: -35.8,
      gold: +52.1,
      silver: +28.4,
      platinum: +12.3,
    },
    color: "#FF4D67",
    severity: "Kritik",
  },
  {
    id: "s4",
    name: "2022 Faiz Artış Dalgası",
    date: "2022",
    description: "Fed agresif faiz artışı başlattı. Gelişmekte olan piyasalardan sermaye çıkışı yaşandı.",
    impact: -14.1,
    details: {
      funds: -18.3,
      gold: -12.4,
      silver: -22.1,
      platinum: -16.8,
    },
    color: "#F59E0B",
    severity: "Orta",
  },
  {
    id: "s5",
    name: "2001 Bankacılık Krizi",
    date: "Şub 2001",
    description: "Türk bankacılık sektörü krizi. IMF müdahalesi. TRY %50 değer kaybetti.",
    impact: -42.8,
    details: {
      funds: -48.2,
      gold: +67.3,
      silver: +31.2,
      platinum: -2.4,
    },
    color: "#FF4D67",
    severity: "Felaket",
  },
];

// ─── Asset Forecast with Confidence Intervals ─────────────────────────────────
const _forecastCache = new Map<string, ReturnType<typeof _buildForecast>>();

function _buildForecast(id: string) {
  const holding = HOLDINGS.find((h) => h.id === id);
  const nav = holding?.nav ?? 100;
  const histValues = genPoints(nav * 0.86, nav, 30, 0.014);
  const fcastValues = genPoints(nav, nav * 1.10, 16, 0.007);

  const historical = histValues.map((v, i) => ({
    i: i.toString(),
    v: parseFloat(v.toFixed(4)),
    bandBase: parseFloat(v.toFixed(4)),
    bandWidth: 0,
    isForecast: false,
  }));

  const forecast = fcastValues.map((v, i) => {
    const uncertainty = v * 0.03 * (1 + i * 0.06);
    return {
      i: (30 + i).toString(),
      v: parseFloat(v.toFixed(4)),
      bandBase: parseFloat((v - uncertainty).toFixed(4)),
      bandWidth: parseFloat((uncertainty * 2).toFixed(4)),
      isForecast: true,
    };
  });

  return [...historical, ...forecast];
}

export function getAssetForecast(id: string) {
  if (!_forecastCache.has(id)) {
    _forecastCache.set(id, _buildForecast(id));
  }
  return _forecastCache.get(id)!;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
export function fmt(n: number, decimals = 2) {
  return n.toLocaleString("tr-TR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function fmtCurrency(n: number) {
  return `₺${fmt(n)}`;
}