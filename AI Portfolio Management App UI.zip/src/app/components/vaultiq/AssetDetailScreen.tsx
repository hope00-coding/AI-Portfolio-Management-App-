import { useState, useMemo, useId } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, Star, TrendingUp, TrendingDown, Info, ShoppingCart, ArrowDownToLine, Brain } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  ComposedChart, Line,
} from "recharts";
import { HOLDINGS, FUND_CATALOG, getAssetChart, getAssetForecast, fmt, fmtCurrency } from "./data";

const RANGES = ["1G", "1H", "1A", "3A", "1Y"] as const;
type Range = typeof RANGES[number];

const RANGE_PERF: Record<Range, (h: typeof HOLDINGS[0]) => number> = {
  "1G": (h) => h.dayChange,
  "1H": (h) => h.dayChange * 5,
  "1A": (h) => h.monthChange,
  "3A": (h) => h.monthChange * 2.8,
  "1Y": (h) => h.ytdChange,
};

function ChartTooltip({ active, payload }: any) {
  if (active && payload?.length) {
    return (
      <div style={{ background: "#1A2035", border: "1px solid rgba(0,212,170,0.3)", borderRadius: 8, padding: "5px 10px" }}>
        <span style={{ color: "#00D4AA", fontSize: 12, fontWeight: 600 }}>
          ₺{fmt(payload[0].value, 4)}
        </span>
      </div>
    );
  }
  return null;
}

export function AssetDetailScreen() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [range, setRange] = useState<Range>("1A");
  const [starred, setStarred] = useState(false);
  const [tab, setTab] = useState<"genel" | "detay">("genel");
  const uid = useId();

  const holding = HOLDINGS.find((h) => h.id === id);
  const catalogItem = FUND_CATALOG.find((f) => f.id === id);

  if (!holding && !catalogItem) {
    return (
      <div style={{ background: "#0A0E1A", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 14 }}>Varlık bulunamadı</p>
          <button onClick={() => navigate(-1)} style={{ color: "#00D4AA", background: "none", border: "none", cursor: "pointer", marginTop: 8, fontSize: 13 }}>
            Geri Dön
          </button>
        </div>
      </div>
    );
  }

  const asset = holding || {
    id: catalogItem!.id,
    name: catalogItem!.name,
    code: catalogItem!.code,
    type: "fund",
    category: catalogItem!.category,
    nav: catalogItem!.nav,
    units: 0,
    value: 0,
    cost: 0,
    dayChange: catalogItem!.change,
    monthChange: catalogItem!.change * 3.5,
    ytdChange: catalogItem!.return1y,
    color: "#00D4AA",
    allocation: 0,
    risk: catalogItem!.risk,
    manager: "Portföy Yöneticisi A.Ş.",
  };

  const [showForecast, setShowForecast] = useState(false);
  const chartData = useMemo(() => getAssetChart(id!, range), [id, range]);
  const forecastData = useMemo(() => getAssetForecast(id!), [id]);
  const perfValue = RANGE_PERF[range](asset as any);
  const isPos = perfValue >= 0;
  const isInPortfolio = !!holding;

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%" }}>
      {/* Header */}
      <div style={{ padding: "12px 16px 0", display: "flex", alignItems: "center", gap: 12 }}>
        <button
          onClick={() => navigate(-1)}
          style={{
            width: 34, height: 34, borderRadius: 10, display: "flex", alignItems: "center",
            justifyContent: "center", background: "rgba(255,255,255,0.06)", border: "none", cursor: "pointer",
          }}
        >
          <ArrowLeft size={16} color="white" />
        </button>
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: 0.5 }}>{asset.category}</p>
          <p style={{ fontSize: 14, fontWeight: 700, color: "white", letterSpacing: -0.3 }}>
            {asset.name.split(" ").slice(0, 4).join(" ")}
          </p>
        </div>
        <button
          onClick={() => setStarred(!starred)}
          style={{ background: "none", border: "none", cursor: "pointer" }}
        >
          <Star size={18} color={starred ? "#F5A623" : "rgba(255,255,255,0.25)"} fill={starred ? "#F5A623" : "none"} />
        </button>
      </div>

      {/* Price + Change */}
      <div style={{ padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 9,
                background: `${asset.color}20`, border: `1.5px solid ${asset.color}35`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 9, fontWeight: 800, color: asset.color,
              }}>
                {asset.code}
              </div>
              {isInPortfolio && (
                <span style={{
                  background: "rgba(0,212,170,0.1)", color: "#00D4AA",
                  fontSize: 9, fontWeight: 700, borderRadius: 5, padding: "2px 7px",
                }}>
                  PORTFÖYİMDE
                </span>
              )}
            </div>
            <p style={{ fontSize: 28, fontWeight: 800, color: "white", letterSpacing: -1, lineHeight: 1 }}>
              ₺{fmt(asset.nav, asset.nav < 1 ? 4 : 2)}
            </p>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 3 }}>
              Birim Pay Değeri
            </p>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 4, justifyContent: "flex-end",
              background: isPos ? "rgba(0,212,170,0.1)" : "rgba(255,77,103,0.1)",
              border: `1px solid ${isPos ? "rgba(0,212,170,0.2)" : "rgba(255,77,103,0.2)"}`,
              borderRadius: 9, padding: "5px 10px", marginBottom: 4,
            }}>
              {isPos ? <TrendingUp size={12} color="#00D4AA" /> : <TrendingDown size={12} color="#FF4D67" />}
              <span style={{ fontSize: 13, fontWeight: 700, color: isPos ? "#00D4AA" : "#FF4D67" }}>
                {isPos ? "+" : ""}{perfValue.toFixed(2)}%
              </span>
            </div>
            <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>{range} performans</p>
          </div>
        </div>
      </div>

      {/* Range / Forecast Toggle */}
      <div style={{ padding: "0 16px 4px" }}>
        <div style={{ display: "flex", gap: 4, marginBottom: 6 }}>
          {RANGES.map((r) => (
            <button
              key={r}
              onClick={() => { setRange(r); setShowForecast(false); }}
              style={{
                flex: 1, height: 28, borderRadius: 8, border: "none", cursor: "pointer",
                fontSize: 11, fontWeight: 600,
                background: !showForecast && range === r ? "#00D4AA" : "rgba(255,255,255,0.05)",
                color: !showForecast && range === r ? "#0A0E1A" : "rgba(255,255,255,0.35)",
                transition: "all 0.2s",
              }}
            >
              {r}
            </button>
          ))}
          <button
            onClick={() => setShowForecast(true)}
            style={{
              flex: 1.3, height: 28, borderRadius: 8, border: "none", cursor: "pointer",
              fontSize: 10, fontWeight: 700,
              background: showForecast ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.05)",
              color: showForecast ? "#6366F1" : "rgba(255,255,255,0.35)",
              transition: "all 0.2s",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 4,
            }}
          >
            <Brain size={10} color={showForecast ? "#6366F1" : "rgba(255,255,255,0.35)"} />
            LSTM
          </button>
        </div>
      </div>

      {/* Chart */}
      {!showForecast ? (
        <div style={{ padding: "8px 0", height: 160 }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 5, right: 16, left: 16, bottom: 0 }}>
              <defs>
                <linearGradient id={`assetGrad-${uid.replace(/:/g, "")}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={asset.color} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={asset.color} stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="i" hide />
              <YAxis domain={["auto", "auto"]} hide />
              <Tooltip content={<ChartTooltip />} />
              <Area
                type="monotone"
                dataKey="v"
                stroke={asset.color}
                strokeWidth={2}
                fill={`url(#assetGrad-${uid.replace(/:/g, "")})`}
                dot={false}
                activeDot={{ r: 4, fill: asset.color, strokeWidth: 0 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      ) : (
        /* LSTM Forecast Chart with Confidence Intervals */
        <div style={{ padding: "0 0", height: 190 }}>
          {/* Hidden SVG gradients */}
          <svg width="0" height="0" style={{ position: "absolute" }}>
            <defs>
              <linearGradient id={`forecastHistGrad-${uid.replace(/:/g, "")}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={asset.color} stopOpacity={0.22} />
                <stop offset="100%" stopColor={asset.color} stopOpacity={0} />
              </linearGradient>
            </defs>
          </svg>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={forecastData} margin={{ top: 8, right: 16, left: 16, bottom: 4 }}>
              <XAxis dataKey="i" hide />
              <YAxis domain={["auto", "auto"]} hide />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0]?.payload;
                  return (
                    <div style={{ background: "#1A2035", border: `1px solid ${asset.color}40`, borderRadius: 8, padding: "5px 10px" }}>
                      <span style={{ color: d?.isForecast ? "#6366F1" : asset.color, fontSize: 12, fontWeight: 600 }}>
                        ₺{fmt(d?.v, 4)}{d?.isForecast ? " (Tahmin)" : ""}
                      </span>
                    </div>
                  );
                }}
              />
              {/* Confidence band lower baseline (transparent, stacks to create offset) */}
              <Area
                type="monotone"
                dataKey="bandBase"
                stackId="ci"
                fill="transparent"
                stroke="none"
                dot={false}
                isAnimationActive={false}
              />
              {/* Confidence band width (fills from bandBase to bandBase+bandWidth) */}
              <Area
                type="monotone"
                dataKey="bandWidth"
                stackId="ci"
                fill="rgba(99,102,241,0.18)"
                stroke="rgba(99,102,241,0.28)"
                strokeWidth={1}
                strokeDasharray="3 3"
                dot={false}
                isAnimationActive={false}
              />
              {/* Historical + Forecast trend line */}
              <Area
                type="monotone"
                dataKey="v"
                stroke={asset.color}
                strokeWidth={2}
                fill={`url(#forecastHistGrad-${uid.replace(/:/g, "")})`}
                dot={false}
                activeDot={{ r: 4, fill: asset.color, strokeWidth: 0 }}
              />
              {/* Forecast portion dashed overlay line */}
              <Line
                type="monotone"
                dataKey="v"
                stroke="#6366F1"
                strokeWidth={2}
                strokeDasharray="5 3"
                dot={false}
                activeDot={false}
                data={forecastData.filter((d) => d.isForecast)}
              />
            </ComposedChart>
          </ResponsiveContainer>

          {/* Confidence interval legend */}
          <div style={{
            display: "flex", alignItems: "center", gap: 14, padding: "0 18px",
            justifyContent: "center",
          }}>
            {[
              { color: asset.color, dash: false, label: "Geçmiş Fiyat" },
              { color: "#6366F1", dash: true, label: "LSTM Tahmini" },
              { color: "rgba(99,102,241,0.5)", dash: true, label: "%90 Güven Bandı" },
            ].map((item) => (
              <div key={item.label} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <svg width="18" height="10">
                  <line
                    x1="0" y1="5" x2="18" y2="5"
                    stroke={item.color}
                    strokeWidth={item.label.includes("Bandı") ? 0 : 2}
                    strokeDasharray={item.dash ? "4 2" : "none"}
                  />
                  {item.label.includes("Bandı") && (
                    <rect x="0" y="2" width="18" height="6" fill="rgba(99,102,241,0.25)" rx="1" />
                  )}
                </svg>
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.38)", fontWeight: 500 }}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Buy / Sell Buttons */}
      <div style={{ padding: "8px 16px 16px", display: "flex", gap: 10 }}>
        <button
          style={{
            flex: 1, height: 46, borderRadius: 13,
            background: "linear-gradient(135deg, #00D4AA, #00A882)",
            color: "#0A0E1A", fontWeight: 700, fontSize: 14, border: "none", cursor: "pointer",
            boxShadow: "0 6px 20px rgba(0,212,170,0.3)",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
          }}
        >
          <ShoppingCart size={15} />
          Al
        </button>
        <button
          style={{
            flex: 1, height: 46, borderRadius: 13,
            background: "rgba(255,77,103,0.1)", border: "1px solid rgba(255,77,103,0.25)",
            color: "#FF4D67", fontWeight: 700, fontSize: 14, cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
          }}
        >
          <ArrowDownToLine size={15} />
          Sat
        </button>
      </div>

      {/* AI Disclaimer */}
      <div style={{ padding: "0 16px 10px" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 7,
          background: "rgba(99,102,241,0.07)", border: "1px solid rgba(99,102,241,0.16)",
          borderRadius: 9, padding: "7px 11px",
        }}>
          <span style={{ fontSize: 11, flexShrink: 0 }}>⚠️</span>
          <p style={{ fontSize: 9.5, color: "rgba(255,255,255,0.42)", lineHeight: 1.45 }}>
            <span style={{ color: "rgba(99,102,241,0.85)", fontWeight: 700 }}>Yalnızca eğitim & karar desteği.</span>{" "}
            Lisanslı finansal tavsiye değildir.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ padding: "0 16px 10px", display: "flex", gap: 4, borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        {[["genel", "Genel Bilgi"], ["detay", "Detaylar"]].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key as any)}
            style={{
              height: 30, paddingLeft: 14, paddingRight: 14, borderRadius: 8, border: "none", cursor: "pointer",
              fontSize: 12, fontWeight: 600,
              background: tab === key ? "#00D4AA" : "transparent",
              color: tab === key ? "#0A0E1A" : "rgba(255,255,255,0.4)",
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "genel" && (
        <div style={{ padding: "16px" }}>
          {/* Key Metrics Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
            {[
              { label: "Günlük Değişim", val: `${asset.dayChange >= 0 ? "+" : ""}${asset.dayChange.toFixed(2)}%`, color: asset.dayChange >= 0 ? "#00D4AA" : "#FF4D67" },
              { label: "Aylık Değişim", val: `+${asset.monthChange.toFixed(2)}%`, color: "#00D4AA" },
              { label: "YTD Getiri", val: `+${asset.ytdChange.toFixed(1)}%`, color: "#00D4AA" },
              { label: "Risk Seviyesi", val: `${asset.risk}/5`, color: "#F5A623" },
            ].map((m) => (
              <div key={m.label} style={{
                background: "rgba(26,32,53,0.6)", border: "1px solid rgba(255,255,255,0.05)",
                borderRadius: 12, padding: "12px 14px",
              }}>
                <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginBottom: 4 }}>{m.label}</p>
                <p style={{ fontSize: 16, fontWeight: 800, color: m.color }}>{m.val}</p>
              </div>
            ))}
          </div>

          {/* Portfolio Position (if held) */}
          {isInPortfolio && holding && (
            <div style={{
              background: "rgba(0,212,170,0.06)", border: "1px solid rgba(0,212,170,0.15)",
              borderRadius: 14, padding: "14px 16px", marginBottom: 16,
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#00D4AA" }} />
                <span style={{ fontSize: 11, fontWeight: 700, color: "#00D4AA", letterSpacing: 0.5 }}>
                  POZİSYONUNUZ
                </span>
              </div>
              <div style={{ display: "flex", gap: 0 }}>
                {[
                  { label: "Birim/Miktar", val: holding.type === "metal" ? `${holding.units}g` : fmt(holding.units, 0) },
                  { label: "Güncel Değer", val: `₺${fmt(holding.value, 0)}` },
                  { label: "Kâr/Zarar", val: `+₺${fmt(holding.value - holding.cost, 0)}` },
                ].map((s, i) => (
                  <div key={s.label} style={{
                    flex: 1, borderLeft: i > 0 ? "1px solid rgba(0,212,170,0.1)" : "none",
                    paddingLeft: i > 0 ? 12 : 0,
                  }}>
                    <p style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginBottom: 3 }}>{s.label}</p>
                    <p style={{ fontSize: 13, fontWeight: 700, color: i === 2 ? "#00D4AA" : "white" }}>{s.val}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* AI Suggestion */}
          <div style={{
            background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.15)",
            borderRadius: 14, padding: "12px 14px",
          }}>
            <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
              <Info size={14} color="#6366F1" style={{ flexShrink: 0, marginTop: 1 }} />
              <div>
                <p style={{ fontSize: 11, fontWeight: 700, color: "#6366F1", marginBottom: 4 }}>AI Değerlendirme</p>
                <p style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", lineHeight: 1.5 }}>
                  Bu fon {asset.category} kategorisinde güçlü performans gösteriyor.{" "}
                  {asset.ytdChange > 20
                    ? "Yüksek getirisini korumak için pozisyonu izlemeye devam edin."
                    : "Orta vadeli yatırım için uygun görünmektedir."}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === "detay" && (
        <div style={{ padding: "16px" }}>
          {/* Fund Details */}
          {[
            { label: "Fon Kodu", val: asset.code },
            { label: "Kategori", val: asset.category },
            { label: "Fon Yöneticisi", val: (asset as any).manager || "Portföy Yönetim A.Ş." },
            { label: "Birim Pay Değeri", val: `₺${fmt(asset.nav, 4)}` },
            { label: "Risk Derecesi", val: `${asset.risk} / 5` },
            { label: "YTD Getiri", val: `%${asset.ytdChange.toFixed(2)}` },
            { label: "Min. Yatırım", val: "₺100" },
            { label: "Alış/Satış", val: "Her iş günü" },
          ].map((row) => (
            <div
              key={row.label}
              style={{
                display: "flex", justifyContent: "space-between",
                padding: "11px 0",
                borderBottom: "1px solid rgba(255,255,255,0.05)",
              }}
            >
              <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>{row.label}</span>
              <span style={{ fontSize: 12, fontWeight: 600, color: "white" }}>{row.val}</span>
            </div>
          ))}

          <div style={{ height: 20 }} />
        </div>
      )}
    </div>
  );
}