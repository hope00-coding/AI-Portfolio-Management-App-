import { useState, useEffect } from "react";
import { X, Check, ChevronDown, Calendar, TrendingUp, TrendingDown } from "lucide-react";
import { HOLDINGS, FUND_CATALOG } from "./data";

interface AddTransactionSheetProps {
  open: boolean;
  onClose: () => void;
  preselectedId?: string;
}

const ALL_ASSETS = [
  ...HOLDINGS.map((h) => ({ id: h.id, name: h.name, code: h.code, color: h.color })),
  ...FUND_CATALOG
    .filter((f) => !HOLDINGS.find((h) => h.id === f.id))
    .map((f) => ({ id: f.id, name: f.name, code: f.code, color: "#00D4AA" })),
];

const TAGS = ["Yatırım Planı", "Araştırma", "Hatırlatıcı", "Diğer"] as const;

export function AddTransactionSheet({ open, onClose, preselectedId }: AddTransactionSheetProps) {
  const [type, setType] = useState<"buy" | "sell">("buy");
  const [assetId, setAssetId] = useState(preselectedId || HOLDINGS[0].id);
  const [amount, setAmount] = useState("");
  const [price, setPrice] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [showAssetPicker, setShowAssetPicker] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (preselectedId) setAssetId(preselectedId);
  }, [preselectedId]);

  useEffect(() => {
    if (!open) {
      setSubmitted(false);
      setAmount("");
      setPrice("");
      setShowAssetPicker(false);
    }
  }, [open]);

  const selectedAsset = ALL_ASSETS.find((a) => a.id === assetId) || ALL_ASSETS[0];
  const total = parseFloat(amount || "0") * parseFloat(price || "0");

  function handleSubmit() {
    if (!amount || !price) return;
    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1400);
  }

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)",
          zIndex: 80, backdropFilter: "blur(4px)",
        }}
      />

      {/* Sheet */}
      <div
        style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          background: "#111827",
          borderTop: "1px solid rgba(255,255,255,0.08)",
          borderRadius: "24px 24px 0 0",
          zIndex: 90,
          padding: "0 0 32px",
          boxShadow: "0 -20px 60px rgba(0,0,0,0.7)",
        }}
      >
        {/* Handle */}
        <div style={{ display: "flex", justifyContent: "center", padding: "12px 0 6px" }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.15)" }} />
        </div>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 20px 16px" }}>
          <div>
            <h3 style={{ fontSize: 16, fontWeight: 800, color: "white", letterSpacing: -0.4 }}>
              İşlem Ekle
            </h3>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>
              Portföyünüze yeni işlem kaydedin
            </p>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 34, height: 34, borderRadius: 10, display: "flex",
              alignItems: "center", justifyContent: "center",
              background: "rgba(255,255,255,0.07)", border: "none", cursor: "pointer",
            }}
          >
            <X size={15} color="rgba(255,255,255,0.6)" />
          </button>
        </div>

        {submitted ? (
          /* Success state */
          <div style={{ padding: "24px 20px 8px", textAlign: "center" }}>
            <div style={{
              width: 64, height: 64, borderRadius: 20, margin: "0 auto 14px",
              background: "rgba(0,212,170,0.15)", border: "1px solid rgba(0,212,170,0.3)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Check size={28} color="#00D4AA" />
            </div>
            <p style={{ fontSize: 16, fontWeight: 800, color: "white", marginBottom: 4 }}>İşlem Kaydedildi!</p>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
              {selectedAsset.code} {type === "buy" ? "alış" : "satış"} işleminiz portföyünüze eklendi.
            </p>
          </div>
        ) : (
          <div style={{ padding: "0 20px" }}>
            {/* Buy / Sell Toggle */}
            <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
              {(["buy", "sell"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setType(t)}
                  style={{
                    flex: 1, height: 42, borderRadius: 12, cursor: "pointer",
                    display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    fontWeight: 700, fontSize: 13,
                    background: type === t
                      ? (t === "buy" ? "rgba(0,212,170,0.15)" : "rgba(255,77,103,0.15)")
                      : "rgba(255,255,255,0.05)",
                    border: type === t
                      ? `1.5px solid ${t === "buy" ? "rgba(0,212,170,0.3)" : "rgba(255,77,103,0.3)"}`
                      : "1.5px solid transparent",
                    color: type === t
                      ? (t === "buy" ? "#00D4AA" : "#FF4D67")
                      : "rgba(255,255,255,0.35)",
                    transition: "all 0.2s",
                  }}
                >
                  {t === "buy" ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {t === "buy" ? "Alış" : "Satış"}
                </button>
              ))}
            </div>

            {/* Asset Selector */}
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
                VARLIK
              </label>
              <button
                onClick={() => setShowAssetPicker(!showAssetPicker)}
                style={{
                  width: "100%", height: 48, borderRadius: 13, border: "1px solid rgba(255,255,255,0.1)",
                  background: "rgba(255,255,255,0.05)", cursor: "pointer",
                  display: "flex", alignItems: "center", padding: "0 14px", gap: 10,
                }}
              >
                <div style={{
                  width: 28, height: 28, borderRadius: 8,
                  background: `${selectedAsset.color}20`,
                  border: `1px solid ${selectedAsset.color}35`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 9, fontWeight: 800, color: selectedAsset.color, flexShrink: 0,
                }}>
                  {selectedAsset.code}
                </div>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: "white", textAlign: "left", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {selectedAsset.name}
                </span>
                <ChevronDown size={14} color="rgba(255,255,255,0.3)" style={{ transform: showAssetPicker ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
              </button>

              {showAssetPicker && (
                <div style={{
                  marginTop: 4, borderRadius: 13, border: "1px solid rgba(255,255,255,0.08)",
                  background: "#1A2035", maxHeight: 150, overflowY: "auto",
                }}>
                  {ALL_ASSETS.slice(0, 8).map((a) => (
                    <button
                      key={a.id}
                      onClick={() => { setAssetId(a.id); setShowAssetPicker(false); }}
                      style={{
                        width: "100%", display: "flex", alignItems: "center", gap: 10,
                        padding: "10px 14px", background: assetId === a.id ? "rgba(0,212,170,0.08)" : "none",
                        border: "none", cursor: "pointer", borderBottom: "1px solid rgba(255,255,255,0.04)",
                      }}
                    >
                      <div style={{
                        width: 24, height: 24, borderRadius: 6,
                        background: `${a.color}20`, border: `1px solid ${a.color}35`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 8, fontWeight: 800, color: a.color, flexShrink: 0,
                      }}>
                        {a.code}
                      </div>
                      <span style={{ fontSize: 12, fontWeight: 500, color: "white", textAlign: "left", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {a.name}
                      </span>
                      {assetId === a.id && <Check size={12} color="#00D4AA" style={{ marginLeft: "auto", flexShrink: 0 }} />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Amount + Price row */}
            <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
                  MİKTAR / BİRİM
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  style={{
                    width: "100%", height: 46, borderRadius: 12,
                    background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                    color: "white", fontSize: 14, fontWeight: 600, padding: "0 12px",
                    outline: "none", boxSizing: "border-box",
                  }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
                  FİYAT (₺)
                </label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="₺0.00"
                  style={{
                    width: "100%", height: 46, borderRadius: 12,
                    background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                    color: "white", fontSize: 14, fontWeight: 600, padding: "0 12px",
                    outline: "none", boxSizing: "border-box",
                  }}
                />
              </div>
            </div>

            {/* Date */}
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.4)", display: "block", marginBottom: 6, letterSpacing: 0.5 }}>
                TARİH
              </label>
              <div style={{ position: "relative" }}>
                <Calendar size={14} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)" }} />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  style={{
                    width: "100%", height: 46, borderRadius: 12,
                    background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                    color: "white", fontSize: 13, fontWeight: 500, padding: "0 12px 0 36px",
                    outline: "none", boxSizing: "border-box", colorScheme: "dark",
                  }}
                />
              </div>
            </div>

            {/* Total preview */}
            {total > 0 && (
              <div style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                background: "rgba(0,212,170,0.06)", border: "1px solid rgba(0,212,170,0.15)",
                borderRadius: 10, padding: "10px 14px", marginBottom: 14,
              }}>
                <span style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>İşlem Tutarı</span>
                <span style={{ fontSize: 15, fontWeight: 800, color: "#00D4AA" }}>
                  ₺{total.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            )}

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={!amount || !price}
              style={{
                width: "100%", height: 50, borderRadius: 14, border: "none", cursor: (!amount || !price) ? "not-allowed" : "pointer",
                fontWeight: 800, fontSize: 14, letterSpacing: 0.2,
                background: (!amount || !price)
                  ? "rgba(255,255,255,0.06)"
                  : (type === "buy"
                    ? "linear-gradient(135deg, #00D4AA, #00A882)"
                    : "linear-gradient(135deg, #FF4D67, #cc3d53)"),
                color: (!amount || !price) ? "rgba(255,255,255,0.25)" : (type === "buy" ? "#0A0E1A" : "white"),
                transition: "all 0.2s",
                boxShadow: (!amount || !price) ? "none" : (type === "buy" ? "0 6px 20px rgba(0,212,170,0.3)" : "0 6px 20px rgba(255,77,103,0.3)"),
              }}
            >
              {type === "buy" ? "Alışı Kaydet" : "Satışı Kaydet"}
            </button>
          </div>
        )}
      </div>
    </>
  );
}