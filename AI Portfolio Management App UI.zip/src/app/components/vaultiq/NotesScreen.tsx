import { useState } from "react";
import { ArrowLeft, Plus, Search, X, Tag, Calendar, ChevronRight, FileText, Trash2 } from "lucide-react";
import { useNavigate } from "react-router";
import { INITIAL_NOTES, Note } from "./data";

const TAG_COLORS: Record<string, { bg: string; color: string }> = {
  "Yatırım Planı": { bg: "rgba(0,212,170,0.12)", color: "#00D4AA" },
  "Araştırma":     { bg: "rgba(99,102,241,0.12)", color: "#6366F1" },
  "Hatırlatıcı":   { bg: "rgba(245,166,35,0.12)", color: "#F5A623" },
  "Diğer":         { bg: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" },
};

const TAG_OPTIONS = ["Yatırım Planı", "Araştırma", "Hatırlatıcı", "Diğer"] as const;

function NoteCard({ note, onClick }: { note: Note; onClick: () => void }) {
  const tagStyle = TAG_COLORS[note.tag] || TAG_COLORS["Diğer"];
  return (
    <div
      onClick={onClick}
      style={{
        background: "rgba(26,32,53,0.7)",
        border: "1px solid rgba(255,255,255,0.06)",
        borderRadius: 16, padding: "14px 16px",
        cursor: "pointer", transition: "border-color 0.15s",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
        <p style={{ fontSize: 14, fontWeight: 700, color: "white", letterSpacing: -0.3, flex: 1, marginRight: 10 }}>
          {note.title}
        </p>
        <ChevronRight size={14} color="rgba(255,255,255,0.2)" style={{ flexShrink: 0, marginTop: 2 }} />
      </div>
      <p style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", lineHeight: 1.5, marginBottom: 10 }}>
        {note.preview}
      </p>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 4,
          background: tagStyle.bg, borderRadius: 6, padding: "3px 8px",
        }}>
          <Tag size={9} color={tagStyle.color} />
          <span style={{ fontSize: 10, fontWeight: 700, color: tagStyle.color }}>{note.tag}</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <Calendar size={10} color="rgba(255,255,255,0.2)" />
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.25)" }}>{note.date}</span>
        </div>
      </div>
    </div>
  );
}

function NoteEditor({
  note,
  onSave,
  onClose,
  onDelete,
  isNew,
}: {
  note: Partial<Note>;
  onSave: (n: Note) => void;
  onClose: () => void;
  onDelete?: () => void;
  isNew: boolean;
}) {
  const [title, setTitle] = useState(note.title || "");
  const [body, setBody] = useState(note.body || "");
  const [tag, setTag] = useState<string>(note.tag || "Araştırma");

  function handleSave() {
    if (!title.trim()) return;
    onSave({
      id: note.id || `n${Date.now()}`,
      title: title.trim(),
      body: body.trim(),
      preview: body.substring(0, 60) + (body.length > 60 ? "..." : ""),
      date: new Date().toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" }),
      tag,
    });
  }

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%", display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px 14px" }}>
        <button
          onClick={onClose}
          style={{
            width: 34, height: 34, borderRadius: 10,
            background: "rgba(255,255,255,0.06)", border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <ArrowLeft size={15} color="rgba(255,255,255,0.7)" />
        </button>
        <p style={{ flex: 1, fontSize: 14, fontWeight: 700, color: "white" }}>
          {isNew ? "Yeni Not" : "Notu Düzenle"}
        </p>
        {!isNew && onDelete && (
          <button
            onClick={onDelete}
            style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}
          >
            <Trash2 size={15} color="#FF4D67" />
          </button>
        )}
        <button
          onClick={handleSave}
          disabled={!title.trim()}
          style={{
            height: 32, paddingLeft: 14, paddingRight: 14, borderRadius: 9, border: "none",
            cursor: title.trim() ? "pointer" : "not-allowed",
            background: title.trim() ? "#00D4AA" : "rgba(255,255,255,0.06)",
            color: title.trim() ? "#0A0E1A" : "rgba(255,255,255,0.2)",
            fontSize: 12, fontWeight: 700,
          }}
        >
          Kaydet
        </button>
      </div>

      <div style={{ flex: 1, padding: "0 16px 24px" }}>
        {/* Tag selector */}
        <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
          {TAG_OPTIONS.map((t) => {
            const ts = TAG_COLORS[t];
            const isActive = tag === t;
            return (
              <button
                key={t}
                onClick={() => setTag(t)}
                style={{
                  height: 28, paddingLeft: 10, paddingRight: 10, borderRadius: 8,
                  border: `1.5px solid ${isActive ? ts.color : "rgba(255,255,255,0.1)"}`,
                  background: isActive ? ts.bg : "transparent",
                  color: isActive ? ts.color : "rgba(255,255,255,0.35)",
                  fontSize: 11, fontWeight: 700, cursor: "pointer",
                  display: "flex", alignItems: "center", gap: 4,
                }}
              >
                <Tag size={9} />
                {t}
              </button>
            );
          })}
        </div>

        {/* Title input */}
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Not başlığı..."
          style={{
            width: "100%", background: "none", border: "none", outline: "none",
            color: "white", fontSize: 20, fontWeight: 800, letterSpacing: -0.5,
            marginBottom: 14, boxSizing: "border-box",
          }}
        />

        <div style={{ height: 1, background: "rgba(255,255,255,0.06)", marginBottom: 14 }} />

        {/* Body textarea */}
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Notunuzu buraya yazın..."
          rows={12}
          style={{
            width: "100%", background: "none", border: "none", outline: "none",
            color: "rgba(255,255,255,0.75)", fontSize: 14, lineHeight: 1.7,
            resize: "none", fontFamily: "inherit", boxSizing: "border-box",
          }}
        />
      </div>
    </div>
  );
}

export function NotesScreen() {
  const navigate = useNavigate();
  const [notes, setNotes] = useState<Note[]>(INITIAL_NOTES);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Partial<Note> | null>(null);
  const [isNew, setIsNew] = useState(false);

  const filtered = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(query.toLowerCase()) ||
      n.body.toLowerCase().includes(query.toLowerCase())
  );

  function openNew() {
    setIsNew(true);
    setEditing({});
  }

  function openEdit(note: Note) {
    setIsNew(false);
    setEditing(note);
  }

  function handleSave(note: Note) {
    setNotes((prev) => {
      const idx = prev.findIndex((n) => n.id === note.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = note;
        return updated;
      }
      return [note, ...prev];
    });
    setEditing(null);
  }

  function handleDelete() {
    if (!editing?.id) return;
    setNotes((prev) => prev.filter((n) => n.id !== editing.id));
    setEditing(null);
  }

  if (editing !== null) {
    return (
      <NoteEditor
        note={editing}
        isNew={isNew}
        onSave={handleSave}
        onClose={() => setEditing(null)}
        onDelete={!isNew ? handleDelete : undefined}
      />
    );
  }

  return (
    <div style={{ background: "#0A0E1A", minHeight: "100%" }}>
      {/* Header */}
      <div style={{ padding: "12px 16px 10px", display: "flex", alignItems: "center", gap: 12 }}>
        <button
          onClick={() => navigate(-1)}
          style={{
            width: 36, height: 36, borderRadius: 11, display: "flex",
            alignItems: "center", justifyContent: "center",
            background: "rgba(255,255,255,0.06)", border: "none", cursor: "pointer",
          }}
        >
          <ArrowLeft size={16} color="white" />
        </button>
        <div style={{ flex: 1 }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, color: "white", letterSpacing: -0.5 }}>Notlarım</h2>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>
            {notes.length} not
          </p>
        </div>
        <button
          onClick={openNew}
          style={{
            width: 36, height: 36, borderRadius: 11, display: "flex",
            alignItems: "center", justifyContent: "center",
            background: "rgba(0,212,170,0.15)", border: "1px solid rgba(0,212,170,0.25)",
            cursor: "pointer",
          }}
        >
          <Plus size={16} color="#00D4AA" />
        </button>
      </div>

      {/* Search */}
      <div style={{ padding: "0 16px 14px" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.08)", borderRadius: 13,
          padding: "0 14px", height: 42,
        }}>
          <Search size={14} color="rgba(255,255,255,0.3)" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Notlarda ara..."
            style={{ flex: 1, background: "none", border: "none", outline: "none", color: "white", fontSize: 13 }}
          />
          {query && (
            <button onClick={() => setQuery("")} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.3)", fontSize: 16, padding: 0 }}>
              ×
            </button>
          )}
        </div>
      </div>

      {/* Notes List */}
      {filtered.length === 0 ? (
        /* Empty state */
        <div style={{ padding: "60px 24px", textAlign: "center" }}>
          <div style={{
            width: 64, height: 64, borderRadius: 20, margin: "0 auto 16px",
            background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <FileText size={26} color="rgba(255,255,255,0.2)" />
          </div>
          <p style={{ fontSize: 15, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 6 }}>
            {query ? "Not Bulunamadı" : "Henüz Not Yok"}
          </p>
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.28)", lineHeight: 1.5, marginBottom: 20 }}>
            {query ? "Farklı bir arama deneyin" : "Yatırım fikirlerinizi, araştırmalarınızı\nve hatırlatıcılarınızı buraya ekleyin."}
          </p>
          {!query && (
            <button
              onClick={openNew}
              style={{
                height: 42, paddingLeft: 20, paddingRight: 20, borderRadius: 12,
                background: "rgba(0,212,170,0.12)", border: "1px solid rgba(0,212,170,0.25)",
                color: "#00D4AA", fontWeight: 700, fontSize: 13, cursor: "pointer",
                display: "inline-flex", alignItems: "center", gap: 6,
              }}
            >
              <Plus size={14} /> İlk Notunu Ekle
            </button>
          )}
        </div>
      ) : (
        <div style={{ padding: "0 16px 28px", display: "flex", flexDirection: "column", gap: 8 }}>
          {filtered.map((note) => (
            <NoteCard key={note.id} note={note} onClick={() => openEdit(note)} />
          ))}
        </div>
      )}

      {/* FAB */}
      {filtered.length > 0 && (
        <button
          onClick={openNew}
          style={{
            position: "absolute", bottom: 80, right: 20,
            width: 50, height: 50, borderRadius: 16,
            background: "linear-gradient(135deg, #00D4AA, #00A882)",
            border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 8px 24px rgba(0,212,170,0.4)",
            zIndex: 20,
          }}
        >
          <Plus size={22} color="#0A0E1A" strokeWidth={2.5} />
        </button>
      )}
    </div>
  );
}
