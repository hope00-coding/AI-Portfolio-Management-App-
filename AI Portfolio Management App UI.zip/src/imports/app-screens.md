4. PORTFOLIO SCREEN
   - Full list of assets with:
     * Asset name/icon
     * Quantity (grams or fund units)
     * Current price
     * Total value
     * % change (colored)
   - Filter tabs at top: "All | Funds | Metals"
   - FAB (Floating Action Button): "+" to add new asset
   - Each row is tappable → goes to Asset Detail screen

5. ASSET DETAIL SCREEN
   - Asset name, type icon, current price (large)
   - Performance chart (line chart) with time range selectors: 1W / 1M / 3M / 1Y / ALL
   - Your holdings section: quantity, average buy price, total invested, current value, 
     profit/loss (with color coding)
   - Transaction history list (buy/sell entries with dates)
   - "Add Transaction" button (bottom)

6. MARKETS SCREEN
   - Live price ticker rows for:
     * Gold (Altın) – TRY/gram + % change
     * Silver (Gümüş)
     * Platinum (Platin)
     * USD/TRY, EUR/TRY, GBP/TRY exchange rates
     * Top 5 TEFAS funds (by popularity)
   - Search bar at top
   - Each item has sparkline mini chart

7. AI ANALYSIS SCREEN
   - Tab bar: "Recommendations | Robustness | Sentiment"
   - RECOMMENDATIONS TAB:
     * AI-generated suggestion cards with title, short description, confidence 
       badge (High/Medium/Low), and action button
     * Disclaimer banner: "For educational purposes only. Not financial advice."
   - ROBUSTNESS TAB:
     * Robustness Score (large circular progress/gauge: e.g., 74/100)
     * Volatility level badge (Low / Medium / High)
     * Historical stress test results: 2008 Crisis, COVID Crash, 2018 EM Selloff — 
       show simulated portfolio performance as a small bar or line for each scenario
   - SENTIMENT TAB:
     * Overall market sentiment gauge (Fearful → Neutral → Greedy)
     * News headlines list with sentiment tag (Positive / Negative / Neutral) 
       shown as colored chips
     * Social media sentiment bar (Twitter/X data)

8. BENCHMARK COMPARISON SCREEN
   - Portfolio vs benchmarks chart (multi-line chart)
   - Selectable benchmarks via toggles: S&P 500 | NASDAQ 100 | Bitcoin | Gold
   - Time range selector: 1M | 3M | 6M | 1Y
   - Performance summary table below chart:
     * Portfolio: +12.4% | S&P 500: +8.1% | BTC: +34.2%
     * Sharpe Ratio, Max Drawdown shown as small stat pills

9. NOTES / PLANNING SCREEN
   - List of user notes (like a minimal note-taking UI)
   - Each note has: title, date, short preview text
   - "+" FAB to add new note
   - Note editor screen: text field with date and tags (e.g., "Investment Plan", 
     "Reminder", "Research")

10. PROFILE / SETTINGS SCREEN
    - User avatar, name, email
    - Settings list items:
      * Currency Preference
      * Notifications
      * Language (Turkish / English)
      * Security (Biometric, PIN)
      * About / Help
    - Log Out button

---